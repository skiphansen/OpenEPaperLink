const $ = document.querySelector.bind(document);

const WAKEUP_REASON_TIMED = 0;
const WAKEUP_REASON_BOOT = 1;
const WAKEUP_REASON_GPIO = 2;
const WAKEUP_REASON_NFC = 3;
const WAKEUP_REASON_BUTTON1 = 4;
const WAKEUP_REASON_BUTTON2 = 5;
const WAKEUP_REASON_BUTTON3 = 6;
const WAKEUP_REASON_FAILED_OTA_FW = 0xE0;
const WAKEUP_REASON_FIRSTBOOT = 0xFC;
const WAKEUP_REASON_NETWORK_SCAN = 0xFD;
const WAKEUP_REASON_WDT_RESET = 0xFE;
const BPP_PACKED_2BIT = 5;

let tagTypes = {};
let apConfig = {};
let tagDB = {};
let favorites = new Set(JSON.parse(localStorage.getItem("favorites") || "[]"));
const previewWindows = [];

const apstate = [
	{ state: "offline, please wait...", color: "orange", icon: "warning" },
	{ state: "online", color: "green", icon: "check_circle" },
	{ state: "flashing", color: "orange", icon: "flash_on" },
	{ state: "wait for reset", color: "blue", icon: "hourglass" },
	{ state: "AP requires reboot", color: "purple", icon: "refresh" },
	{ state: "failed", color: "red", icon: "error" },
	{ state: "coming online...", color: "orange", icon: "hourglass" },
	{ state: "AP without radio", color: "green", icon: "wifi_off" }
];
const runstate = [
	{ state: "⏹︎ stopped" },
	{ state: "⏸ pause" },
	{ state: "" }, // hide running
	{ state: "⏳︎ init" }
];

const imageQueue = [];
let isProcessing = false;
let servertimediff = 0;
let paintLoaded = false, paintShow = false;
let cardconfig;
let otamodule, flashmodule;
let socket;
let finishedInitialLoading = false;
let getTagtypeBusy = false;

const loadConfig = new Event("loadConfig");
window.addEventListener("loadConfig", function () {
	fetch("get_ap_config")
		.then(response => response.json())
		.then(data => {
			apConfig = data;

			if (data.alias) {
				$(".logo").innerHTML = data.alias;
				this.document.title = data.alias;
			}
			if (data.C6 == 1 || (data.H2 && data.H2 == 1)) {
				var optionToRemove = $("#apcfgchid").querySelector('option[value="27"]');
				if (optionToRemove) $("#apcfgchid").removeChild(optionToRemove);
			}
			if (data.hasFlasher == 1) {
				$('[data-target="flashtab"]').style.display = 'block';
			}
			if (data.hasBLE == 0) {
				$("#apcfgble").parentNode.style.display = 'none';
			}
			if (data.hasSubGhz == 0) {
				$("#apcfgsubgigchid").parentNode.style.display = 'none';
			}
			if (data.savespace) {
			}
			if (data.apstate) {
				$("#apstatecolor").innerHTML = apstate[data.apstate].icon;
				$("#apstatecolor").style.color = apstate[data.apstate].color;
				$("#apstate").innerHTML = apstate[data.apstate].state;
				$('#dashboardStatus').innerHTML = apstate[data.apstate].state;
				$('#dashboardStatus').style.color = apstate[data.apstate].color;
				$('#dashboardStatusIcon').innerHTML = apstate[data.apstate].icon;
				$('#dashboardStatusIcon').style.color = apstate[data.apstate].color;
			}
		});
});

window.addEventListener("load", function () {
	const themeToggle = $('#theme-toggle');
	if (themeToggle) {
		const THEME_STORAGE_KEY = 'theme';
		const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
		let hasExplicitPreference = localStorage.getItem(THEME_STORAGE_KEY) !== null;

		const setTheme = (theme, persist = true) => {
			const isDark = theme === 'dark';
			document.body.classList.toggle('dark-mode', isDark);
			themeToggle.innerHTML = isDark ? 'dark_mode' : 'light_mode';
			themeToggle.title = isDark ? 'Switch to light mode' : 'Switch to dark mode';
			themeToggle.setAttribute('aria-label', themeToggle.title);
			if (persist) {
				localStorage.setItem(THEME_STORAGE_KEY, theme);
				hasExplicitPreference = true;
			}
		};

		themeToggle.addEventListener('click', () => {
			const isDarkMode = document.body.classList.contains('dark-mode');
			setTheme(isDarkMode ? 'light' : 'dark', true);
		});

		prefersDarkScheme.addEventListener('change', (event) => {
			if (!hasExplicitPreference) {
				setTheme(event.matches ? 'dark' : 'light', false);
			}
		});

		const savedTheme = localStorage.getItem(THEME_STORAGE_KEY);
		if (savedTheme === 'dark' || savedTheme === 'light') {
			setTheme(savedTheme, false);
		} else {
			hasExplicitPreference = false;
			setTheme(prefersDarkScheme.matches ? 'dark' : 'light', false);
		}
	}
	window.dispatchEvent(loadConfig);
	initTabs();
	fetch('content_cards.json')
		.then(response => response.json())
		.then(data => {
			cardconfig = data;
			loadTags(0)
				.then(() => {
					finishedInitialLoading = true;
					connect();
				})
				.catch(error => showMessage('loadTags error: ' + error));
			setInterval(updatecards, 1000);
		})
		.catch(error => {
			console.error('Error:', error);
			alert("I can't load /www/content_cards.json.\r\nHave you upload it to the data partition?");
		});

	dropUpload();
	populateTimes($('#apcnight1'));
	populateTimes($('#apcnight2'));

	document.addEventListener('DOMContentLoaded', function () {
		var faviconLink = document.createElement('link');
		faviconLink.rel = 'icon';
		faviconLink.href = 'favicon.ico';
		document.head.appendChild(faviconLink);
	});
});

/* tabs */
let activeTab = '', previousTab = '';

function initTabs() {
	const tabLinks = document.querySelectorAll(".tablinks");
	const tabContents = document.querySelectorAll(".tabcontent");

	tabLinks.forEach(tabLink => {
		tabLink.addEventListener("click", function (event) {
			event.preventDefault();
			const targetId = this.getAttribute("data-target");
			const url = new URL(window.location);
			if (targetId === 'tagtab') {
				if (url.searchParams.get('tab') !== 'tagtab') {
					url.searchParams.set('tab', 'tagtab');
					history.replaceState(null, '', url);
				}
			} else {
				if (url.searchParams.has('tab')) {
					url.searchParams.delete('tab');
					history.replaceState(null, '', url);
				}
			}
			const loadTabEvent = new CustomEvent('loadTab', { detail: targetId });
			document.dispatchEvent(loadTabEvent);
			tabContents.forEach(tabContent => {
				tabContent.style.display = "none";
			});
			tabLinks.forEach(link => {
				link.classList.remove("active");
			});
			if (targetId == "logtab") document.getElementById(targetId).scrollTop = 0;
			document.getElementById(targetId).style.display = "block";
			this.classList.add("active");
		});
	});

	const urlParams = new URLSearchParams(window.location.search);
	const tabToOpen = urlParams.get('tab');
	const targetTabLink = document.querySelector(`.tablinks[data-target="${tabToOpen}"]`);
	if (targetTabLink) {
		targetTabLink.click();
	} else {
		tabLinks[0].click();
	}
};

function loadTags(pos) {
	return fetch("get_db?pos=" + pos)
		.then(response => response.json())
		.then(data => {
			processTags(data.tags);
			if (data.continu && data.continu > pos) {
				return loadTags(data.continu);
			}
		});
}

function formatUptime(seconds) {
	const days = Math.floor(seconds / (24 * 60 * 60));
	const hours = Math.floor((seconds % (24 * 60 * 60)) / (60 * 60));
	const minutes = Math.floor((seconds % (60 * 60)) / 60);
	const remainingSeconds = seconds % 60;

	const components = [
		{ value: days, label: 'd' },
		{ value: hours, label: 'h' },
		{ value: minutes, label: 'm' },
		{ value: remainingSeconds, label: 's' }
	];

	let formattedUptime = '';

	components.forEach(({ value, label }) => {
		if (value > 0 || formattedUptime !== '') {
			formattedUptime += `${value}${label} `;
		}
	});

	return formattedUptime.trim();
}

function connect() {
	protocol = location.protocol == "https:" ? "wss://" : "ws://";
	socket = new WebSocket(protocol + location.host + location.pathname + "ws");

	socket.addEventListener("open", (event) => {
		showMessage("websocket connected");
	});

	socket.addEventListener("message", (event) => {
		if ($('#showdebug').checked) {
			showMessage(event.data);
			console.log(event.data);
		}
		const msg = JSON.parse(event.data);
		if (msg.logMsg) {
			showMessage(msg.logMsg, false);
		}
		if (msg.errMsg) {
			showMessage(msg.errMsg, true);
		}
		if (msg.tags) {
			processTags(msg.tags);
		}
		if (msg.sys) {
			Object.assign(lastSys, msg.sys);
			let str = "";
			str += `free heap: ${convertSize(msg.sys.heap)} &#x2507; `;
			if (msg.sys.psfree) {
				str += `free PSRAM: ${convertSize(msg.sys.psfree)}  &#x2507; `;
			}
			str += `db size: ${convertSize(msg.sys.dbsize)} &#x2507; `;
			str += `db record count: ${msg.sys.recordcount} &#x2507; `;

			if (msg.sys.littlefsfree < 31000) {
				str += `filesystem <span class="blink-red" title="Generating content is paused">FULL! ${convertSize(
					msg.sys.littlefsfree
				)} </span>`;
			} else {
				str += `filesystem free: ${convertSize(msg.sys.littlefsfree)}`;
			}
			str += ` &#x2507; uptime: ${formatUptime(msg.sys.uptime)}`;

			$("#sysinfo").innerHTML = str;

			if (msg.sys.apstate) {
				$("#runstate").innerHTML = runstate[msg.sys.runstate].state;
				$("#apstatecolor").innerHTML = apstate[msg.sys.apstate].icon;
				$("#apstatecolor").style.color = apstate[msg.sys.apstate].color;
				$("#apstate").innerHTML = apstate[msg.sys.apstate].state;
				$('#dashboardStatus').innerHTML = apstate[msg.sys.apstate].state;
				$('#dashboardStatus').style.color = apstate[msg.sys.apstate].color;
				$('#dashboardStatusIcon').innerHTML = apstate[msg.sys.apstate].icon;
				$('#dashboardStatusIcon').style.color = apstate[msg.sys.apstate].color;				
			}
			servertimediff = (Date.now() / 1000) - msg.sys.currtime;
		}
		if (msg.apitem) {
			apList[msg.apitem.ip] = msg.apitem;
			populateAPCard(msg.apitem);
		}
		if (msg.touch) {
			// Real touch positions from a touch-capable AP (e.g. 4inch GT911).
			// Protocol: {touch:{count:N, points:[{id,x,y,size},...]}}, count 0 = release.
			// Consume it from your own code with:
			//   window.addEventListener('oepltouch', e => console.log(e.detail));
			window.dispatchEvent(new CustomEvent('oepltouch', { detail: msg.touch }));
		}
		if (msg.upload) {
			showUploadProgress(msg.upload);
		}
		if (msg.console) {
			if (activeTab == 'flashtab' && flashmodule && typeof (flashmodule.print) === "function") {
				let color = (msg.color ? msg.color : "#c0c0c0");
				if (msg.console.startsWith("Fail") || msg.console.startsWith("Err")) {
					color = "red";
				}
				flashmodule.print(msg.console, color);
			} else if (otamodule && typeof (otamodule.print) === "function") {
				let color = "#c0c0c0";
				if (msg.console.startsWith("Fail") || msg.console.startsWith("Err")) {
					color = "red";
				}
				otamodule.print(msg.console, color);
			}
		}
	});

	socket.addEventListener("close", (event) => {
		showMessage(`websocket closed ${event.code}`);
		setTimeout(connect, 5000);
	});
}

function convertSize(bytes) {
	if (bytes >= 1073741824) { bytes = (bytes / 1073741824).toFixed(2) + " GB"; }
	else if (bytes >= 1048576) { bytes = (bytes / 1048576).toFixed(2) + " MB"; }
	else if (bytes >= 1024) { bytes = (bytes / 1024).toFixed(2) + " kB"; }
	else if (bytes > 1) { bytes = bytes + " bytes"; }
	else if (bytes == 1) { bytes = bytes + " byte"; }
	else { bytes = "0 bytes"; }
	return bytes;
}

function clearTagStateClasses(tagElement) {
	tagElement.classList.remove(
		'state-deepsleep',
		'state-boot',
		'state-wakeup',
		'state-scan',
		'state-reset',
		'state-failed-ota'
	);
}

function processTags(tagArray) {
	for (const element of tagArray) {
		const tagmac = element.mac;
		tagDB[tagmac] = element;

		let div = $('#tag' + tagmac);
		if (div == null) {
			div = $('#tagtemplate').cloneNode(true);
			div.setAttribute('id', 'tag' + tagmac);
			div.dataset.mac = tagmac;
			div.dataset.hwtype = -1;
			div.classList.toggle('favorite', favorites.has(tagmac));
			$('#taglist').appendChild(div);
		}

		div.style.display = 'block';

		if (element.contentMode == 255) {
			div.remove();
			showMessage(tagmac + " removed by remote AP");
			continue;
		}

		if (element.isexternal) {
			$('#tag' + tagmac + ' .mac').innerHTML = tagmac + " via ext AP";
		} else {
			$('#tag' + tagmac + ' .mac').innerHTML = tagmac;
		}
		let alias = element.alias;
		if (!alias && tagmac.startsWith('2446')) {
			alias = 'OD' + tagmac.slice(-6);  // OpenDisplay tags call themselves that
		} else if (!alias) {
			alias = tagmac.replace(/^0{1,4}/, '');
			if (alias.match(/^4467/)) {
				let macdigit = Number.parseInt(alias.substr(4, 2), 16) & 0x1f;
				let model = String.fromCharCode(macdigit + 65);
				if (model >= 'A' && model <= 'Z') {
					macdigit = Number.parseInt(alias.substr(6, 2), 16) & 0x1f;
					model += String.fromCharCode(macdigit + 65);
					alias = model + alias.substr(8, 8) + 'x'
				}
			}
		}
		if ($('#tag' + tagmac + ' .alias').innerHTML != alias) {
			$('#tag' + tagmac + ' .alias').innerHTML = alias;
		}

		let contentDefObj = getContentDefById(element.contentMode);
		if (contentDefObj) $('#tag' + tagmac + ' .contentmode').innerHTML = contentDefObj.name;
		if (element.RSSI) {
			div.dataset.hwtype = element.hwType;
			(async () => {
				const localTagmac = tagmac;
				const data = await getTagtype(element.hwType, element.isexternal ? element.apip : null);
				div.dataset.usetemplate = data.usetemplate;
				if (data.usetemplate != 0) {
					const template = await getTagtype(data.usetemplate);
					// a type the AP made itself has no content list of its own
					if (!data.contentids?.length && template?.contentids) data.contentids = template.contentids;
				}
				$('#tag' + localTagmac + ' .model').innerHTML = data.name;
				$('#tag' + localTagmac + ' .resolution').innerHTML = data.width + "x" + data.height;
				if (element.od && element.hwType == 0x100) {
					// OpenDisplay tag whose type the AP doesn't know yet
					$('#tag' + localTagmac + ' .model').innerHTML = element.od.width ? 'OpenDisplay ' + element.od.colors : 'OpenDisplay, ' + element.od.state;
					$('#tag' + localTagmac + ' .resolution').innerHTML = element.od.width ? element.od.width + "x" + element.od.height : '';
				}
				if (element.od && element.ver) {
					$('#tag' + localTagmac + ' .resolution').innerHTML += ` fw:${element.ver >> 8}.${element.ver & 0xff}`;
				} else if (element.ver != 0 && element.ver != 1) {
					div.dataset.ver = element.ver;
					$('#tag' + localTagmac + ' .resolution').innerHTML += ` fw:${element.ver} 0x${element.ver.toString(16)}`;
				}

				if (!apConfig.preview || element.contentMode == 20) {
					$('#tag' + tagmac + ' .tagimg').style.display = 'none'
				} else if (div.dataset.hash != element.hash && div.dataset.hwtype > -1) {
					let cachetag = element.hash;
					if (element.hash != '00000000000000000000000000000000') {
						if (element.isexternal && element.contentMode == 12) {
							loadImage(tagmac, 'http://' + tagDB[tagmac].apip + '/current/' + tagmac + '.raw?' + cachetag);
						} else {
							loadImage(tagmac, 'current/' + tagmac + '.raw?' + cachetag);
						}
					} else {
						$('#tag' + tagmac + ' .tagimg').style.display = 'none'
					}
					div.dataset.hash = element.hash;
				}
			})();

			let statusline = "";
			if (element.RSSI != 100) {
				if (element.ch > 0) statusline += `CH ${element.ch}, `;
				statusline += `RSSI ${element.RSSI}, LQI ${element.LQI}`;
			} else {
				statusline = "AP";
			}
			if (element.batteryMv != 0 && element.batteryMv != 1337) {
				statusline += ", " + (element.batteryMv == 2600 ? "&#x2265;" : "") + (element.batteryMv / 1000) + "V";
			}
			$('#tag' + tagmac + ' .received').innerHTML = statusline;
			$('#tag' + tagmac + ' .received').style.opacity = "1";

		} else {
			$('#tag' + tagmac + ' .model').innerHTML = "waiting for hardware type";
			$('#tag' + tagmac + ' .received').style.opacity = "0";
			$('#tag' + tagmac + ' .resolution').innerHTML = "";
		}

		if (element.nextupdate > 1672531200 && element.nextupdate != 3216153600) {
			const date = new Date(element.nextupdate * 1000);
			const options = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false };
			$('#tag' + tagmac + ' .nextupdate').innerHTML = "<span>next update</span>" + date.toLocaleString('nl-NL', options);
		} else {
			$('#tag' + tagmac + ' .nextupdate').innerHTML = "";
		}
		if (element.nextupdate < (Date.now() / 1000) - servertimediff) {
			$('#tag' + tagmac + ' .waitingicon').style.display = 'inline-block';
		} else {
			$('#tag' + tagmac + ' .waitingicon').style.display = 'none';
		}

		if (element.nextcheckin > 1672531200) {
			div.dataset.nextcheckin = element.nextcheckin;
		} else {
			div.dataset.nextcheckin = element.lastseen + 60;
		}

		div.style.opacity = '1';
		$('#tag' + tagmac + ' .lastseen').style.color = "";
		div.classList.remove("tagpending");
		div.dataset.lastseen = element.lastseen;
		div.dataset.wakeupreason = element.wakeupReason;
		div.dataset.nextupdate = element.nextupdate;
		div.dataset.channel = element.ch;
		div.dataset.isexternal = element.isexternal;
		$('#tag' + tagmac + ' .warningicon').style.display = 'none';
		
		div.style.background = '';
		div.classList.remove('state-timeout');
		clearTagStateClasses(div);
		
		let stateClassSet = false;
		switch (parseInt(element.wakeupReason)) {
			case WAKEUP_REASON_TIMED:
				break;
			case WAKEUP_REASON_BOOT:
			case WAKEUP_REASON_FIRSTBOOT:
				$('#tag' + tagmac + ' .nextcheckin').innerHTML = "<font color=yellow>First boot</font>"
				div.classList.add("state-boot");
				stateClassSet = true;
				break;
			case WAKEUP_REASON_GPIO:
			case WAKEUP_REASON_BUTTON1:
			case WAKEUP_REASON_BUTTON2:
			case WAKEUP_REASON_BUTTON3:
			case WAKEUP_REASON_NFC:
				let reasonText = {
					[WAKEUP_REASON_GPIO]: "GPIO wakeup",
					[WAKEUP_REASON_BUTTON1]: "Button 1 pressed",
					[WAKEUP_REASON_BUTTON2]: "Button 2 pressed",
					[WAKEUP_REASON_BUTTON3]: "Button 3 pressed",
					[WAKEUP_REASON_NFC]: "NFC wakeup"
				}[parseInt(element.wakeupReason)];
				$('#tag' + tagmac + ' .nextcheckin').innerHTML = reasonText;
				div.classList.add("state-wakeup");
				stateClassSet = true;
				break;
			case WAKEUP_REASON_NETWORK_SCAN:
				$('#tag' + tagmac + ' .nextcheckin').innerHTML = "<font color=yellow>Network scan</font>"
				div.classList.add("state-scan");
				stateClassSet = true;
				break;
			case WAKEUP_REASON_WDT_RESET:
				$('#tag' + tagmac + ' .nextcheckin').innerHTML = "Watchdog reset!"
				div.classList.add("state-reset");
				stateClassSet = true;
				break;
			case WAKEUP_REASON_FAILED_OTA_FW:
				$('#tag' + tagmac + ' .nextcheckin').innerHTML = "Firmware update rejected!"
				div.classList.add("state-failed-ota");
				stateClassSet = true;
				break;
		}		
		if (!stateClassSet && (element.contentMode == 12 || element.nextcheckin == 3216153600)) {
			div.classList.add("state-deepsleep");
		}		
		$('#tag' + tagmac + ' .pendingicon').style.display = (element.pending ? 'inline-block' : 'none');
		$('#tag' + tagmac + ' .pendingicon').innerHTML = element.pending;
		div.classList.add("tagflash");
		(function (tagmac) {
			setTimeout(function () { $('#tag' + tagmac).classList.remove("tagflash"); }, 1400);
		})(tagmac);
		if (element.pending) div.classList.add("tagpending");

		previewWindows.forEach((previewWindow, index) => {
			if (previewWindow && !previewWindow.closed) {
				if (previewWindow.mac === tagmac) {
					previewWindow.updateMessage(element);
				}
			} else {
				previewWindows.splice(index, 1);
			}
		});
	}
	GroupSortFilter();
}

function updatecards() {
	if (servertimediff > 1000000000) servertimediff = 0;
	let tagcount = 0;
	let pendingcount = 0;
	let timeoutcount = 0;
	let lowbattcount = 0;

	$('#taglist').querySelectorAll('[data-mac]').forEach(item => {
		let tagmac = item.dataset.mac;
		tagcount++;
		if (tagDB[tagmac].batteryMv < 2400 && tagDB[tagmac].batteryMv != 0 && tagDB[tagmac].batteryMv != 1337) lowbattcount++;
		if (item.dataset.lastseen && item.dataset.lastseen > (Date.now() / 1000) - servertimediff - 30 * 24 * 3600 * 60) {
			let idletime = (Date.now() / 1000) - servertimediff - item.dataset.lastseen;
			$('#tag' + tagmac + ' .lastseen').innerHTML = "<span>last seen</span>" + displayTime(Math.floor(idletime)) + " ago";	
			if ((Date.now() / 1000) - servertimediff - apConfig.maxsleep * 60 - 300 > item.dataset.nextcheckin) {
				item.querySelector('.warningicon').style.display = 'inline-block';
				item.classList.remove("tagpending");
				item.classList.add('state-timeout');
				timeoutcount++;
			} else {
				item.classList.remove('state-timeout');
				if (tagDB[tagmac].pending) pendingcount++;
			}
			
			const lastseenEl = item.querySelector('.lastseen');
			if (idletime > 24 * 3600) {
				item.style.opacity = '.5';
				lastseenEl.classList.add('error');
			} else {
				item.style.opacity = '1';
				lastseenEl.classList.remove('error');
			}
		} else {
			if ($('#tag' + tagmac + ' .lastseen')) {
				$('#tag' + tagmac + ' .lastseen').innerHTML = ""
			} else {
				console.log(tagmac + " not found")
			}
		}

		if (item.dataset.nextcheckin == 3216153600) {
			$('#tag' + tagmac + ' .nextcheckin').innerHTML = "In deep sleep";
		} else if (item.dataset.nextcheckin > 1672531200 && parseInt(item.dataset.wakeupreason) == 0) {
			let nextcheckin = item.dataset.nextcheckin - ((Date.now() / 1000) - servertimediff);
			$('#tag' + tagmac + ' .nextcheckin').innerHTML = "<span>expected checkin</span>" + displayTime(Math.floor(nextcheckin));
		} else {
			// $('#tag' + tagmac + ' .nextcheckin').innerHTML = "";
		}

		if (item.dataset.nextupdate < (Date.now() / 1000) - servertimediff) {
			$('#tag' + tagmac + ' .waitingicon').style.display = 'inline-block';
		} else {
			$('#tag' + tagmac + ' .waitingicon').style.display = 'none';
		}
	})

	$('#dashboardTagCount').innerHTML = tagcount;
	$('#dashboardPending').innerHTML = pendingcount;
	$('#dashboardLowBatt').innerHTML = lowbattcount;
	$('#dashboardTimeout').innerHTML = timeoutcount;
	renderDashboard();
}

$('#clearlog').addEventListener("click", (event) => {
	$('#messages').innerHTML = '';
});

document.querySelectorAll('.closebtn').forEach(button => {
	button.addEventListener('click', (event) => {
		event.target.parentNode.style.display = 'none';
		$('#advancedoptions').style.height = '0px';
	});
});

document.querySelectorAll('.closebtn2').forEach(button => {
	button.addEventListener('click', (event) => {
		event.target.parentNode.close();
		$('#advancedoptions').style.height = '0px';
	});
});

//clicking on a tag: load config dialog for tag
$('#taglist').addEventListener("click", (event) => {
	let currentElement = event.target;
	while (currentElement !== $('#taglist')) {
		if (currentElement.classList.contains("tagcard")) {
			break;
		}
		currentElement = currentElement.parentNode;
	}
	if (!currentElement.classList.contains("tagcard")) {
		return;
	}
	const mac = currentElement.dataset.mac;
	if (event.target.classList.contains("favoriteicon")) {
		toggleFavorite(mac);
		return;
	}
	loadContentCard(mac);
})

function toggleFavorite(mac) {
	if (favorites.has(mac)) favorites.delete(mac); else favorites.add(mac);
	localStorage.setItem("favorites", JSON.stringify([...favorites]));
	$('#tag' + mac)?.classList.toggle('favorite', favorites.has(mac));
	GroupSortFilter();
}

function loadContentCard(mac) {
	$('#cfgmac').innerHTML = mac;
	$('#cfgmac').dataset.mac = mac;
	fetch("get_db?mac=" + mac)
		.then(response => response.json())
		.then(data => {
			const tagdata = data.tags[0];
			$('#cfgalias').value = tagdata.alias;
			$('#cfgmore').style.display = "none";
			if (populateSelectTag(tagdata.hwType, tagdata.capabilities)) {
				$('#cfgcontent').parentNode.style.display = "flex";
				$('#cfgcontent').value = tagdata.contentMode;
				$('#cfgcontent').dataset.json = tagdata.modecfgjson;
				contentselected();
				if (tagdata.contentMode != 12) $('#cfgmore').style.display = 'block';
			} else {
				$('#customoptions').innerHTML = "";
				$('#cfgcontent').parentNode.style.display = "none";
			}
			$('#cfgrotate').value = tagdata.rotate;
			$('#cfglut').value = tagdata.lut;
			$('#cfginvert').value = tagdata.invert;
			$('#cfgmore').innerHTML = '&#x25BC;';
			$('#cfgmac').dataset.ch = tagdata.ch;
			loadOdKeyState(mac);
			$('#configbox').showModal();
		})
}

// OpenDisplay BLE tags: the AP only connects to tags the user added, with their key or without
// one. It only says whether it has a key, never the key itself.
function loadOdKeyState(mac) {
	$('#cfgodkey').value = '';
	$('#cfgodkeyrow').style.display = 'none';
	$('#cfgodkeybuttons').style.display = 'none';
	if (!mac.startsWith('2446')) return;
	fetch('od_key?mac=' + mac)
		.then(response => response.ok ? response.json() : null)
		.then(state => {
			if (!state) return;
			$('#cfgodkey').placeholder = state.set ? 'set (type to replace)' : state.added ? 'added without key' : 'not added';
			$('#cfgodkeyadd').style.display = state.added ? 'none' : '';
			$('#cfgodkeyclear').style.display = state.added ? '' : 'none';
			$('#cfgodkeyrow').style.display = '';
			$('#cfgodkeybuttons').style.display = '';
		});
}

function postOdKey(mac, params) {
	let formData = new FormData();
	formData.append("mac", mac);
	for (const [name, value] of Object.entries(params)) formData.append(name, value);
	return fetch("od_key", { method: "POST", body: formData })
		.then(response => response.text().then(text => showMessage(text, !response.ok)))
		.catch(error => showMessage('Error: ' + error, true));
}

$('#cfgodkeyadd').onclick = function () {
	const mac = $('#cfgmac').dataset.mac;
	postOdKey(mac, { add: 1 }).then(() => loadOdKeyState(mac));
}

$('#cfgodkeyclear').onclick = function () {
	const mac = $('#cfgmac').dataset.mac;
	postOdKey(mac, { key: '' }).then(() => loadOdKeyState(mac));
}

let typedString = '';
document.addEventListener('keypress', (event) => {
	const keyPressed = event.key;
	if (keyPressed.length === 1) {
		typedString += keyPressed;
	} else if (keyPressed === 'Enter') {
		typedString = ('0000' + typedString).slice(-16);
		const hexRegExp = /^[0-9A-Fa-f]{16}$/;
		const isMac = typedString.match(hexRegExp);
		if (isMac) {
			console.log('scanned ' + typedString);
			loadContentCard(typedString);
		}
		typedString = '';
	}
});

$('#cfgmore').onclick = function () {
	$('#cfgmore').innerHTML = $('#advancedoptions').style.height == '0px' ? '&#x25B2;' : '&#x25BC;';
	$('#advancedoptions').style.height = $('#advancedoptions').style.height == '0px' ? $('#advancedoptions').scrollHeight + 'px' : '0px';
};

$('#cfgsave').onclick = function () {
	const odKey = $('#cfgodkey').value.trim();
	if (odKey != '') {
		if (!/^[0-9a-fA-F]{32}$/.test(odKey)) {
			showMessage('The encryption key is 32 hex digits', true);
			return;
		}
		postOdKey($('#cfgmac').dataset.mac, { key: odKey });
	}
	let contentMode = $('#cfgcontent').value;
	let contentDef = getContentDefById(contentMode);
	let extraoptions = contentDef?.param ?? null;
	let obj = {};

	let formData = new FormData();
	formData.append("mac", $('#cfgmac').dataset.mac);
	formData.append("alias", $('#cfgalias').value);

	if (contentMode) {
		extraoptions?.forEach(element => {
			if (document.getElementById('opt' + element.key)) {
				obj[element.key] = document.getElementById('opt' + element.key).value;
			}
		});
		formData.append("contentmode", contentMode);
		formData.append("modecfgjson", JSON.stringify(obj));
	} else {
		formData.append("contentmode", "0");
		formData.append("modecfgjson", String());
	}

	formData.append("rotate", $('#cfgrotate').value);
	formData.append("lut", $('#cfglut').value);
	formData.append("invert", $('#cfginvert').value);

	fetch("save_cfg", {
		method: "POST",
		body: formData
	})
		.then(response => response.text())
		.then(data => showMessage(data))
		.catch(error => showMessage('Error: ' + error, true));

	$('#advancedoptions').style.height = '0px';
	$('#configbox').close();
	backupTagDB();
}

function sendCmd(mac, cmd) {
	let formData = new FormData();
	formData.append("mac", mac);
	formData.append("cmd", cmd);
	fetch("tag_cmd", {
		method: "POST",
		body: formData
	})
		.then(response => response.text())
		.then(data => {
			let div = $('#tag' + mac);
			if (cmd == "del") div.remove();
			showMessage(data);
		})
		.catch(error => showMessage('Error: ' + error, true));
	$('#advancedoptions').style.height = '0px';
	$('#configbox').close();
}

$('#cfgdelete').onclick = function () {
	sendCmd($('#cfgmac').dataset.mac, "del");
}

$('#cfgclrpending').onclick = function () {
	sendCmd($('#cfgmac').dataset.mac, "clear");
}

$('#cfgrefresh').onclick = function () {
	sendCmd($('#cfgmac').dataset.mac, "refresh");
}

$('#cfgtagreboot').onclick = function () {
	sendCmd($('#cfgmac').dataset.mac, "reboot");
}

$('#cfgscan').onclick = function () {
	sendCmd($('#cfgmac').dataset.mac, "scan");
}

$('#cfgdeepsleep').onclick = function () {
	sendCmd($('#cfgmac').dataset.mac, "deepsleep");
}

$('#cfgreset').onclick = function () {
	sendCmd($('#cfgmac').dataset.mac, "reset");
}

$('#cfgautoupdate').onclick = async function () {
	let obj = {};
	let formData = new FormData();
	var mac = $('#cfgmac').dataset.mac;
	formData.append("mac", mac);
	formData.append("alias", $('#cfgalias').value);

	var repo = apConfig.repo || 'OpenEPaperLink/OpenEPaperLink';
	var infourl = "https://raw.githubusercontent.com/" + repo + "/master/binaries/Tag/tagotaversions.json";
	var info = "";
	await fetch(infourl, { method: 'GET' }).then(await function (response) { return response.json(); }).then(await function (json) { info = json; });
	var tagtype = hwTypeHex($('#tag' + mac).dataset.hwtype);
	var name = info[0][tagtype]?.["type"];
	if (!name) {
		alert("Tag id not known");
		return false;
	}
	var version = info[0][tagtype]["version"];
	var md5 = info[0][tagtype]["md5"];

	if (name.substr(0, 6) == "chroma") {
		var variation = (Number.parseInt(mac.substr(4, 2), 16) >> 5).toString();
		if (variation != '0') {
			var name = info[0][tagtype]["type_" + variation];
			version = info[0][tagtype]['version_' + variation];
			md5 = info[0][tagtype]['md5_' + variation];
		}
	}

	var currentversion = $('#tag' + mac).dataset.ver | 0;
	if (confirm(`Current version: ${currentversion} 0x${currentversion.toString(16)}\nPending version: ${parseInt(version, 16)} 0x${parseInt(version, 16).toString(16)}\n\nNOTE: Every OTA update comes with a risk of bricking the tag, if it is bricked, it only can be recoverd with a tag flasher. Please only update if you need the new features.\n\nPress Cancel if you want to get out of here, or press OK if you want to proceed with the update.`)) {

		var fullFilename = name + "_" + version + ".bin";
		var filepath = "/" + fullFilename;
		var binurl = "https://raw.githubusercontent.com/" + repo + "/master/binaries/Tag/" + fullFilename;
		var url = "check_file?path=" + encodeURIComponent(filepath);
		var response = await fetch(url);
		if (response.ok) {
			var data = await response.json();
			if (data.filesize == 0 || data.md5 != md5) {
				try {
					var response = await fetch(binurl);
					var fileContent = await response.blob();
					var formData2 = new FormData();
					formData2.append('path', filepath);
					formData2.append('file', fileContent, fullFilename);
					var uploadResponse = await fetch('littlefs_put', {
						method: 'POST',
						body: formData2
					});
					if (!uploadResponse.ok) {
						showMessage('Error: auto update failed to upload', true);
					}
				} catch (error) {
					showMessage('Error: ' + error, true);
				}
			}
		} else showMessage('Error: auto update failed', true);
		var response = await fetch(url);
		if (response.ok) {
			var data = await response.json();
			if (data.filesize == 0 || data.md5 != md5) {
				showMessage('Error: auto update failed to download. File is empty or md5 check fails', true);
			}
			//sucess
			else obj["filename"] = filepath;
		}
		else showMessage('Error: auto update failed', true);
		formData.append("contentmode", 5);
		formData.append("modecfgjson", JSON.stringify(obj));
		fetch("save_cfg", {
			method: "POST",
			body: formData
		})
			.then(response => response.text())
			.then(data => showMessage(data))
			.catch(error => showMessage('Error: ' + error, true));
	}
	$('#configbox').close();
}

$('#rebootbutton').onclick = function (event) {
	event.preventDefault();
	if (!confirm('Reboot AP now?')) return;
	socket.close();
	fetch("reboot", {
		method: "POST"
	});
	alert('Rebooted. Webpage will reload.');
	location.reload()
}

$('#configbox').addEventListener('click', (event) => {
	if (event.target.nodeName === 'DIALOG') {
		$('#configbox').close();
	}
});

document.addEventListener("loadTab", function (event) {
	activeTab = event.detail;
	document.body.dataset.tab = activeTab;
	switch (event.detail) {
		case 'configtab':
		case 'aptab':
			fetch("get_ap_config")
				.then(response => response.json())
				.then(data => {
					if (data && 'alias' in data) {
						apConfig = data;
						$('#apcfgalias').value = data.alias;
						$('#apcfgchid').value = data.channel;
						$('#apcfgsubgigchid').value = data.subghzchannel;
						$('#apcfgble').value = data.ble;
						$("#apcfgledbrightness").value = data.led;
						$("#apcfgtftbrightness").value = data.tft;
						$("#apcfglanguage").value = data.language;
						$("#apclatency").value = data.maxsleep;
						$("#apcpreventsleep").value = data.stopsleep;
						$("#apcpreview").value = data.preview;
						$("#apcnightlyreboot").value = data.nightlyreboot;
						$("#apclock").value = data.lock;
						$("#apcwifipower").value = data.wifipower;
						$("#apchotspotpw").value = data.hotspotpw || "";
						$("#apctimezone").value = data.timezone;
						$("#apcnight1").value = data.sleeptime1;
						$("#apcnight2").value = data.sleeptime2;
						$("#apcdiscovery").value = data.discovery;
						$("#apcshowtimestamp").value = data.showtimestamp;
						if (data.owm_api_key !== undefined) {
							$("#owm_api_key").value = data.owm_api_key;
						}
						else  {
							$("#owm_api_key").value = "";
						}
					}
				})
			$('#apcfgmsg').innerHTML = '';
			break;
		case 'updatetab':
			$('#updateconsole').innerHTML = '';
			loadOTA();
			break;
		case 'flashtab':
			// $('#flashconsole').innerHTML = '';
			loadFlash();
			break;
	}
	if (previousTab == 'flashtab' && activeTab != 'flashtab' && flashmodule && typeof (flashmodule.wsCmd) === "function") {
		flashmodule.wsCmd(flashmodule.WEBFLASH_BLUR);
	}
	previousTab = activeTab;
});

$('#apcfgsave').onclick = function () {
	const apiKey = $('#owm_api_key').value.trim();
	if (apiKey != 0) {
		const hexRegExp = /^[0-9A-Fa-f]{32}$/;
		const isKey = hexRegExp.test(apiKey);
		if(!isKey) {
			console.log('Api key ' + apiKey + ' is invalid');
			$('#apcfgmsg').innerHTML = 'Error: OWM API key is invalid.\r\nValid API keys are 32 hex characters';
			return;
		}
	}

	let formData = new FormData();
	formData.append("alias", $('#apcfgalias').value);
	formData.append("channel", $('#apcfgchid').value);
	formData.append("subghzchannel", $('#apcfgsubgigchid').value);
	formData.append('ble', $('#apcfgble').value);
	formData.append('led', $('#apcfgledbrightness').value);
	formData.append('tft', $('#apcfgtftbrightness').value);
	formData.append('language', $('#apcfglanguage').value);
	formData.append('maxsleep', $('#apclatency').value);
	formData.append('stopsleep', $('#apcpreventsleep').value);
	formData.append('preview', $('#apcpreview').value);
	formData.append('nightlyreboot', $('#apcnightlyreboot').value);
	formData.append('lock', $('#apclock').value);
	formData.append('wifipower', $('#apcwifipower').value);
	const hotspotpw = $('#apchotspotpw').value;
	if (hotspotpw.length > 0 && (hotspotpw.length < 8 || hotspotpw.length > 63)) {
		$('#apcfgmsg').innerHTML = 'Hotspot password needs 8 to 63 characters';
		return;
	}
	formData.append('hotspotpw', hotspotpw);
	formData.append('timezone', $('#apctimezone').value);
	formData.append('sleeptime1', $('#apcnight1').value);
	formData.append('sleeptime2', $('#apcnight2').value);
	formData.append('discovery', $('#apcdiscovery').value);
	formData.append('showtimestamp', $('#apcshowtimestamp').value);
	formData.append('owm_api_key', $('#owm_api_key').value);
	fetch("save_apcfg", {
		method: "POST",
		body: formData
	})
		.then(response => response.text())
		.then(data => {
			showMessage(data);
			window.dispatchEvent(loadConfig);
			$('#apcfgmsg').innerHTML = 'OK, Saved';
		})
		.catch(error => showMessage('Error: ' + error, true));
}

$('#uploadButton').onclick = function () {
	const file = $('#fileInput')?.files[0];
	if (file) {
		const formData = new FormData();
		formData.append('file', file);
		fetch('restore_db', {
			method: 'POST',
			body: formData
		})
			.then(response => {
				if (!response.ok) {
					throw new Error(`HTTP error! Status: ${response.status}`);
				}
				return response.text();
			})
			.then(data => {
				alert('TagDB restored. Webpage will reload.');
				location.reload();
			})
			.catch(error => {
				alert('Error uploading file: ' + error);
			});
	} else {
		alert('No file selected');
	}
}

$('#restoreFromLocal').onclick = function () {
	var tagDBrestore = localStorage.getItem('tagDB');
	if (tagDBrestore) {
		tagDBobj = JSON.parse(tagDBrestore);
		var tagResult = [];

		for (var key in tagDBobj) {
			if (tagDBobj.hasOwnProperty(key)) {
				tagResult.push([tagDBobj[key]]);
			}
		}

		const blob = new Blob([JSON.stringify(tagResult, null, '\t')], { type: 'application/json' });
		const formData = new FormData();
		formData.append('file', blob, 'tagResult.json');

		fetch('restore_db', {
			method: 'POST',
			body: formData
		})
			.then(response => {
				if (!response.ok) {
					throw new Error(`HTTP error! Status: ${response.status}`);
				}
				return response.text();
			})
			.then(data => {
				alert('TagDB restored. Webpage will reload.');
				location.reload();
			})
			.catch(error => {
				alert('Error uploading file: ' + error);
			});
	} else {
		alert('No data found in localStorage');
	}
}

async function loadOTA() {
	otamodule = await import('./ota.js?v=' + Date.now());
	otamodule.initUpdate();
}

async function loadFlash() {
	flashmodule = await import('./flash.js?v=' + Date.now());
	flashmodule.init();
}

$('#paintbutton').onclick = function () {
	if (paintShow) {
		paintShow = false;
		$('#cfgsave').parentNode.style.display = 'block';
		contentselected();
	} else {
		paintShow = true;
		$('#cfgsave').parentNode.style.display = 'none';
		$('#customoptions').innerHTML = "<div id=\"buttonbar\"></div><div id=\"canvasdiv\"></div><div id=\"layersdiv\"></div><p id=\"savebar\"></p>";
		const mac = $('#cfgmac').dataset.mac
		const hwtype = $('#tag' + mac).dataset.hwtype;
		const [width, height] = [tagTypes[hwtype].width, tagTypes[hwtype].height] || [0, 0];
		if (paintLoaded) {
			startPainter(mac, width, height, tagTypes[hwtype]);
		} else {
			loadScript('painter.js', function () {
				startPainter(mac, width, height, tagTypes[hwtype]);
			});
		}
	}
}

function loadScript(url, callback) {
	let script = document.createElement('script');
	script.src = url;
	script.onload = function () {
		if (callback) {
			callback();
		}
	};
	document.head.appendChild(script);
}

function contentselected() {
	let contentMode = $('#cfgcontent').value;
	$('#customoptions').innerHTML = "";
	let obj = {};
	if ($('#cfgcontent').dataset.json && ($('#cfgcontent').dataset.json != "null")) {
		obj = JSON.parse($('#cfgcontent').dataset.json);
	}
	$('#paintbutton').style.display = 'none';
	if (contentMode) {
		let contentDef = getContentDefById(contentMode);
		if (contentDef) {
			$('#customoptions').innerHTML = "<p>" + contentDef?.desc + "</p>"
		}
		$('#paintbutton').style.display = (contentMode == 22 || contentMode == 23 ? 'inline-block' : 'none');
		let extraoptions = contentDef?.param ?? null;
		extraoptions?.forEach(element => {
			if(!MeetsRequirments(element,$('#tag' + $('#cfgmac').dataset.mac).dataset.hwtype,1)) {
				return;
			}
			let label = document.createElement("label");
			label.innerHTML = element.name;
			label.setAttribute("for", 'opt' + element.key);
			if (element.desc) {
				label.style.cursor = 'help';
				label.title = element.desc;
			}
			let input = document.createElement("input");
			switch (element.type) {
				case 'text':
					input.type = "text";
					break;
				case 'int':
					input.type = "number";
					break;
				case 'ro':
					input.type = "text";
					input.disabled = true;
					break;
				case 'jpgfile':
				case 'binfile':
				case 'jsonfile':
					input = document.createElement("select");
					fetch('edit?list=%2F&recursive=1&nosize=1')
						.then(response => response.json())
						.then(data => {
							let files = data.filter(item => item.type === "file" && (item.name.toLowerCase().endsWith(".jpg") || item.name.toLowerCase().endsWith(".jpeg")));
							if (element.type == 'binfile') files = data.filter(item => item.type === "file" && item.name.endsWith(".bin"));
							if (element.type == 'jsonfile') files = data.filter(item => item.type === "file" && item.name.endsWith(".json"));
							const optionElement = document.createElement("option");
							optionElement.value = "";
							optionElement.text = "";
							input.appendChild(optionElement);
							files.forEach(item => {
								const optionElement = document.createElement("option");
								optionElement.value = item.name;
								optionElement.text = item.name;
								if (obj[element.key] === item.name) optionElement.selected = true;
								input.appendChild(optionElement);
							})
						})
						.catch(error => {
							console.error("Error fetching JSON data:", error);
						});
					break;
				case 'select':
			    case 'chanselect':
				case 'apiselect':
					input = document.createElement("select");
					let options;
					if (element.type == 'chanselect') {
						if ($('#cfgmac').dataset.ch < 100) {
							options = element.chans;
						}
						else {
							options = element.subchans;
						}
					}
					else {
						options = element.options;
					}

					for (const key in options) {
						const optionElement = document.createElement("option");
						optionElement.value = key;
						optionElement.text = options[key];
						if (options[key].substring(0, 1) == "-") {
							optionElement.text = options[key].substring(1);
							optionElement.selected = true;
						} else {
							optionElement.selected = false;
						}
						input.appendChild(optionElement);
					}
					break;
				case 'geoselect':
					input.type = "text";
					input.classList.add("geoselect");
					input.setAttribute("autocomplete", "off");
					break;

				case 'noaaselect':
					input.type = "text";
					input.classList.add("noaaselect");
					input.setAttribute("autocomplete", "off");
					break;
          
				case 'checkbox':
					input.type = "checkbox";
					input.classList.add("checkbox");
					break;
			}
			input.id = 'opt' + element.key;
			input.title = element.desc;
			if (obj[element.key]) input.value = obj[element.key];
			let p = document.createElement("p");
			p.appendChild(label);
			p.appendChild(input);
			if (element.type == 'geoselect') {
				input.addEventListener('input', debounce(searchLocations, 300));
				const resultsContainer = document.createElement('div');
				resultsContainer.id = 'georesults';
				p.appendChild(resultsContainer);
			}
			else if (element.type == 'noaaselect') {
				input.addEventListener('input', debounce(NoaaSearch, 300));
				const resultsContainer = document.createElement('div');
				resultsContainer.id = 'georesults';
				p.appendChild(resultsContainer);
			}
			else if (element.type == 'apiselect') {
				input.addEventListener('change', handleApiChange);
			}

			if(element.api) {
				let DivName = 'ApiDiv' + element.api;
				document.getElementById(DivName).appendChild(p);
			}
			else {
				$('#customoptions').appendChild(p);
			}

			if (element.type == 'apiselect' ) {
				options = element.options;
				for (const key in options) {
				// create div for options specific to this API 
					let apiOptionsDiv = document.createElement('div');
					apiOptionsDiv.id = 'ApiDiv' + key;
					apiOptionsDiv.style.display = 'none';

					$('#customoptions').appendChild(apiOptionsDiv);
				 // disable owm API unless key is set
					if(options[key] == "openweathermap.org" && apConfig.owm_api_key == 0) {
						optionElement.selected = false;
						optionElement.disabled = true;
					}
				}
				handleApiChange();
			}
		});
	}
	paintShow = false;
	$('#cfgsave').parentNode.style.display = 'block';
}

function MeetsRequirments(item,hwtype,default_ret)
{
	Supported = default_ret;
	HasRequirments = item.requirements ?? 0;
	if(HasRequirments) {
		Supported = 1;
		if(item.requirements.minX && item.requirements.minX > tagTypes[hwtype].width) {
			Supported = 0;
		}
		else if(item.requirements.minY && item.requirements.minY > tagTypes[hwtype].height) {
			Supported = 0;
		}
		else if(item.requirements.maxX && item.requirements.maxX < tagTypes[hwtype].width) {
			Supported = 0;
		}
		else if(item.requirements.maxY && item.requirements.maxY < tagTypes[hwtype].height) {
			Supported = 0;
		}
		console.log(tagTypes[hwtype].width + "x" + tagTypes[hwtype].height + " tag is " + (Supported ? "" : "not ") + "supported by requirments.");
	}
	return Supported;
}


function populateSelectTag(hwtype, capabilities) {
	let selectTag = $("#cfgcontent");
	selectTag.innerHTML = "";
	let optionsAdded = false;
	let option;
	cardconfig.forEach(item => {
		const capcheck = item.capabilities ?? 0;
		const Supported = tagTypes[hwtype].contentids?.includes(item.id) || MeetsRequirments(item,hwtype,1);
		if (Supported && (capabilities & capcheck || capcheck == 0) && (apConfig.savespace == 0 || !item.properties?.includes("savespace"))) {
			option = document.createElement("option");
			option.value = item.id;
			option.text = item.name;
			selectTag.appendChild(option);
			optionsAdded = true;
		}
	});

	let rotateTag = $("#cfgrotate");
	rotateTag.innerHTML = "";

	for (let i = 0; i < 4; i++) {
		if (i == 0 || tagTypes[hwtype].width == tagTypes[hwtype].height || (i == 2)) {
			option = document.createElement("option");
			option.value = i;
			option.text = (i * 90) + " degrees";
			rotateTag.appendChild(option);
		}
	}

	let lutTag = $("#cfglut");
	lutTag.innerHTML = "";

	option = document.createElement("option");
	option.value = "0";
	if (tagTypes[hwtype].shortlut == 0) {
		option.text = "Always full refresh";
	} else {
		option.text = "auto";
	}
	lutTag.appendChild(option);

	if (tagTypes[hwtype].shortlut > 0) {
		option = document.createElement("option");
		option.value = "1";
		option.text = "Always full refresh";
		lutTag.appendChild(option);
		option = document.createElement("option");
		option.value = "2";
		option.text = "Fast (no reds)";
		lutTag.appendChild(option);
		option = document.createElement("option");
		option.value = "3";
		option.text = "Fastest (ghosting!)";
		lutTag.appendChild(option);
	}

	return optionsAdded;
}

function getContentDefById(id) {
	if (id == null) return null;
	const obj = cardconfig.find(item => item.id == id);
	return obj || null;
}

const uploadTimers = {};
// Live data-upload progress on a tag card.
// Protocol: {upload:{src:"<16hex MAC>", current:N, total:M}} (current>=total = done).
function showUploadProgress(u) {
	const src = (u.src || '').toUpperCase();
	const div = $('#tag' + src);
	if (!div) return;
	const el = div.querySelector('.uploadstatus');
	if (!el) return;
	const total = u.total || 0;
	const current = u.current || 0;
	const pct = total > 0 ? Math.min(100, Math.round(current / total * 100)) : 0;
	el.textContent = pct + '% (' + current + '/' + total + ')';
	el.style.setProperty('--pct', pct + '%');
	el.style.display = 'block';
	// Auto-hide: shortly after completion, or after a stall (aborted / tag offline).
	if (uploadTimers[src]) clearTimeout(uploadTimers[src]);
	const hideDelay = (total > 0 && current >= total) ? 2000 : 20000;
	uploadTimers[src] = setTimeout(() => {
		el.style.display = 'none';
		delete uploadTimers[src];
	}, hideDelay);
}

function showMessage(message, iserr) {
	const messages = $('#messages');
	const date = new Date();
	const time = date.toLocaleTimeString('nl-NL', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
	if (message.startsWith('{')) {
		messages.insertAdjacentHTML("afterbegin", '<li class="new">' + htmlEncode(time) + ' <span class="mono">' + message.replace(/"([^"]+)"/g, '"<span class="quote">$1</span>"') + '</span></li>');
	} else if (iserr) {
		messages.insertAdjacentHTML("afterbegin", '<li class="new error">' + htmlEncode(time + ' ' + message) + '</li>');
	} else {
		messages.insertAdjacentHTML("afterbegin", '<li class="new">' + htmlEncode(time + ' ' + message) + '</li>');

		const hexRegex = /^[0-9A-Fa-f]{16}.*/;
		if (hexRegex.test(message.substring(0, 16))) {
			let div = $('#tag' + message.substring(0, 16));
			if (div) {
				div.classList.add("tagxfer");
				(function (tagmac) {
					setTimeout(function () { $('#tag' + tagmac).classList.remove("tagxfer"); }, 200);
				})(message.substring(0, 16));
			}
		}
	}
}

function htmlEncode(input) {
	const textArea = document.createElement("textarea");
	textArea.innerText = input;
	return textArea.innerHTML.split("<br>").join("\n");
}

function loadImage(id, imageSrc) {
	imageQueue.push({ id, imageSrc });
	if (!isProcessing) {
		processQueue();
	}
}

function processQueue() {
	if (imageQueue.length === 0) {
		isProcessing = false;
		return;
	}
	isProcessing = true;
	if (!finishedInitialLoading) {
		setTimeout(processQueue, 100);
		return;
	}
	const { id, imageSrc } = imageQueue.shift();
	const hwtype = $('#tag' + id).dataset?.hwtype;
	if (tagTypes[hwtype]?.busy) {
		imageQueue.push({ id, imageSrc });
		setTimeout(processQueue, 100);
		return;
	};

	const canvas = $('#tag' + id + ' .tagimg');
	canvas.style.display = 'block';

	fetch(imageSrc, { cache: "force-cache" })
		.then(response => response.arrayBuffer())
		.then(buffer => {

			drawCanvas(buffer, canvas, hwtype, id);
			processQueue();
		})
		.catch(error => {
			console.error('processQueue error:', error);
			processQueue();
		});
}

function drawCanvas(buffer, canvas, hwtype, tagmac) {
	data = new Uint8ClampedArray(buffer);
	if (data.length > 0 && tagTypes[hwtype].zlib > 0 && $('#tag' + tagmac).dataset.ver >= tagTypes[hwtype].zlib) {
		data = processZlib(data);
	}
	if (data.length > 0 && tagTypes[hwtype].g5 > 0 && $('#tag' + tagmac).dataset.ver >= tagTypes[hwtype].g5) {
		const headerSize = data[0];
		let bufw = (data[2] << 8) | data[1];
		let bufh = (data[4] << 8) | data[3];
		if ((bufw == tagTypes[hwtype].width || bufw == tagTypes[hwtype].height) && (bufh == tagTypes[hwtype].width || bufh == tagTypes[hwtype].height) && (data[5] <= 3)) {
			// valid header for g5 compression
			if (data[5] == 2) bufh *= 2;
			data = processG5(data.subarray(headerSize), bufw, bufh);
		}
	}

	[canvas.width, canvas.height] = [tagTypes[hwtype].width, tagTypes[hwtype].height] || [0, 0];
	if (tagTypes[hwtype].rotatebuffer % 2) [canvas.width, canvas.height] = [canvas.height, canvas.width];
	if (tagTypes[hwtype].rotatebuffer >= 2) canvas.style.transform = 'rotate(180deg)';
	const ctx = canvas.getContext('2d');
	const imageData = ctx.createImageData(canvas.width, canvas.height);
	if (data.length == 0) {
		canvas.style.display = 'none';
	}

	if (tagTypes[hwtype].bpp == 16) {
		const is16Bit = data.length == tagTypes[hwtype].width * tagTypes[hwtype].height * 2;
		for (let i = 0; i < min(tagTypes[hwtype].width * tagTypes[hwtype].height, data.length); i++) {
			const dataIndex = is16Bit ? i * 2 : i;
			const rgb = is16Bit ? (data[dataIndex] << 8) | data[dataIndex + 1] : data[dataIndex];

			imageData.data[i * 4] = is16Bit ? ((rgb >> 11) & 0x1F) << 3 : (((rgb >> 5) & 0x07) << 5) * 1.13;
			imageData.data[i * 4 + 1] = is16Bit ? ((rgb >> 5) & 0x3F) << 2 : (((rgb >> 2) & 0x07) << 5) * 1.13;
			imageData.data[i * 4 + 2] = is16Bit ? (rgb & 0x1F) << 3 : ((rgb & 0x03) << 6) * 1.3;
			imageData.data[i * 4 + 3] = 255;
		}

	} else if ([3, 4, BPP_PACKED_2BIT].includes(tagTypes[hwtype].bpp)) {
		const bpp = tagTypes[hwtype].bpp === BPP_PACKED_2BIT ? 2 : tagTypes[hwtype].bpp;
		const colorTable = tagTypes[hwtype].colortable;
		let pixelIndex = 0;
		let bitOffset = 0;

		while (bitOffset < data.length * 8 && pixelIndex < canvas.width * canvas.height) {
			let byteIndex = bitOffset >> 3; 
			let startBit = bitOffset & 7; 
			let pixelValue = (data[byteIndex] << 8 | data[byteIndex + 1] || 0) >> (16 - bpp - startBit) & ((1 << bpp) - 1);
			let color = colorTable[pixelValue];
			imageData.data[pixelIndex * 4] = color[0];
			imageData.data[pixelIndex * 4 + 1] = color[1];
			imageData.data[pixelIndex * 4 + 2] = color[2];
			imageData.data[pixelIndex * 4 + 3] = 255;
			pixelIndex++;
			bitOffset += bpp;
		}
	} else {

		const offsetRed = (data.length >= (canvas.width * canvas.height / 8) * 2) ? canvas.width * canvas.height / 8 : 0;
		let pixelValue = 0;
		const colorTable = tagTypes[hwtype].colortable;
		for (let i = 0; i < data.length; i++) {
			for (let j = 0; j < 8; j++) {
				const pixelIndex = i * 8 + j;
				if (offsetRed) {
					pixelValue = ((data[i] & (1 << (7 - j))) ? 1 : 0) | (((data[i + offsetRed] & (1 << (7 - j))) ? 1 : 0) << 1);
				} else {
					pixelValue = ((data[i] & (1 << (7 - j))) ? 1 : 0);
				}
				imageData.data[pixelIndex * 4] = colorTable[pixelValue][0];
				imageData.data[pixelIndex * 4 + 1] = colorTable[pixelValue][1];
				imageData.data[pixelIndex * 4 + 2] = colorTable[pixelValue][2];
				imageData.data[pixelIndex * 4 + 3] = 255;
			}
		}
	}

	ctx.putImageData(imageData, 0, 0);
}

function processZlib(data) {
	const subBuffer = data.subarray(4);
	try {
		const inflatedBuffer = pako.inflate(subBuffer);
		// to constrain window size for testing:
		// const inflatedBuffer = pako.inflate(subBuffer, { windowBits: 12 });
		const headerSize = inflatedBuffer[0];
		return inflatedBuffer.subarray(headerSize);
	} catch (err) {
		console.log('zlib: ' + err);
	}
}

function displayTime(seconds) {
	let hours = Math.floor(Math.abs(seconds) / 3600);
	let minutes = Math.floor((Math.abs(seconds) % 3600) / 60);
	let remainingSeconds = Math.abs(seconds) % 60;
	return (seconds < 0 ? '-' : '') + (hours > 0 ? `${hours}:${String(minutes).padStart(2, '0')}` : `${minutes}`) + `:${String(remainingSeconds).padStart(2, '0')}`;
}

$("#filterOptions").addEventListener("click", function (event) {
	if (event.target.tagName === "INPUT") {
		GroupSortFilter();
	}
});

let filtersRestored = false;

function GroupSortFilter() {
	const sortableGrid = $('#taglist');
	const gridItems = Array.from(sortableGrid.querySelectorAll('.tagcard:not(#tagtemplate)'));

	const filterBoxes = Array.from(document.querySelectorAll('input[name="filter"]'));
	if (!filtersRestored) {
		const storedFilters = JSON.parse(localStorage.getItem("filters") || "[]");
		filterBoxes.forEach(checkbox => checkbox.checked = storedFilters.includes(checkbox.value));
		filtersRestored = true;
	} else {
		localStorage.setItem("filters", JSON.stringify(filterBoxes.filter(checkbox => checkbox.checked).map(checkbox => checkbox.value)));
	}

	let grouping = document.querySelector('input[name="group"]:checked')?.value;
	if (grouping == undefined) {
		grouping = localStorage.getItem("grouping");
		if (grouping) document.querySelector('input[name="group"][value="' + grouping + '"]').checked = true
	} else {
		localStorage.setItem("grouping", grouping);
	}
	let sorting = document.querySelector('input[name="sort"]:checked')?.value ?? 'alias';

	gridItems.sort((a, b) => {
		let itemA = String(sorting).startsWith('data-') ? a.dataset[sorting.slice(5)] : a.querySelector('.' + sorting).textContent;
		let itemB = String(sorting).startsWith('data-') ? b.dataset[sorting.slice(5)] : b.querySelector('.' + sorting).textContent;
		if (sorting == 'data-lastseen') [itemA, itemB] = [itemB, itemA];
		if (grouping) {
			let groupA = String(grouping).startsWith('data-') ? a.dataset[grouping.slice(5)] : a.querySelector('.' + grouping).textContent;
			let groupB = String(grouping).startsWith('data-') ? b.dataset[grouping.slice(5)] : b.querySelector('.' + grouping).textContent;
			if (groupA !== groupB) {
				return groupA.localeCompare(groupB);
			} else {
				return itemA.localeCompare(itemB);
			}
		} else {
			return itemA.localeCompare(itemB);
		}
	});

	const visible = new Map();
	gridItems.forEach(item => {
		let show = true;
		let batteryMv = tagDB[item.dataset.mac].batteryMv;
		if ($('input[name="filter"][value="remote"]').checked && item.dataset.isexternal == "false") show = false;
		if ($('input[name="filter"][value="local"]').checked && item.dataset.isexternal == "true") show = false;
		if ($('input[name="filter"][value="inactive"]').checked && item.querySelector('.warningicon').style.display != 'inline-block') show = false;
		if ($('input[name="filter"][value="pending"]').checked && !item.classList.contains("tagpending")) show = false;
		if ($('input[name="filter"][value="lowbatt"]').checked && (batteryMv >= 2400 || batteryMv == 0 || batteryMv == 1337)) show = false;
		if ($('input[name="filter"][value="favorites"]').checked && !favorites.has(item.dataset.mac)) show = false;
		visible.set(item, show);
	});

	// counts only the tags that pass the filters; a group without any gets no header
	let groupCounts = {};
	if (grouping) {
		gridItems.forEach(item => {
			if (!visible.get(item)) return;
			const g = String(grouping).startsWith('data-') ? item.dataset[grouping.slice(5)] || '' : item.querySelector('.' + grouping).textContent || '';
			if (g == '') return;
			if (!groupCounts[g]) groupCounts[g] = { total: 0, pending: 0, offline: 0 };
			groupCounts[g].total++;
			if (item.classList.contains('tagpending')) groupCounts[g].pending++;
			const warn = item.querySelector('.warningicon');
			if (item.classList.contains('state-timeout') || (warn && warn.style.display == 'inline-block')) groupCounts[g].offline++;
		});
	}

	let currentGroup = null;
	let order = 1;

	let headItems = Array.from($('#taglist').getElementsByClassName('taggroup'));
	headItems.forEach(item => {
		item.dataset.clean = 1;
	})

	gridItems.forEach(item => {

		if (grouping) {
			const group = String(grouping).startsWith('data-') ? item.dataset[grouping.slice(5)] || '' : item.querySelector('.' + grouping).textContent || '';
			if (group !== currentGroup && group != '' && groupCounts[group]) {
				let header = document.getElementById('header' + group);
				if (!header) {
					header = document.createElement('div');
					header.classList.add('taggroup');
					header.id = 'header' + group;
					sortableGrid.appendChild(header);
				}
				let groupLabel = group;
				switch (grouping) {
					case 'model':
						groupLabel = 'Tag model: ' + group;
						break;
					case 'contentmode':
						groupLabel = 'Content: ' + group;
						break;
					case 'data-channel':
						groupLabel = 'Channel: ' + group;
						break;
				}
				const gc = groupCounts[group];
				header.textContent = groupLabel + ' - ' + gc.total + ' pcs, ' + gc.pending + ' pending, ' + gc.offline + ' offline';
				header.style.order = order++;
				header.dataset.clean = 0;
				currentGroup = group;
			}
		}

		item.style.display = visible.get(item) ? 'block' : 'none';
		item.style.order = order++;
		const checkedValues = Array.from(document.querySelectorAll('input[name="filter"]:checked'))
			.map(checkbox => checkbox.value)
			.join(', ');
		$('#activefilter').innerHTML = (checkedValues ? 'filtered by ' + checkedValues + '<button class="material-symbols-outlined clearfilter" title="Clear filter">close</button>' : '');
	});

	headItems = Array.from($('#taglist').getElementsByClassName('taggroup'));
	headItems.forEach(item => {
		if (item.dataset.clean == 1) item.parentNode.removeChild(item);
	})
}

$('#toggleFilters').addEventListener('click', (event) => {
	event.preventDefault();
	const filterOptions = $('#filterOptions');
	filterOptions.classList.toggle('active');
	if (filterOptions.classList.contains('active')) {
		filterOptions.style.maxHeight = filterOptions.scrollHeight + 20 + 'px';
	} else {
		filterOptions.style.maxHeight = 0;
	}
});

$('#activefilter').addEventListener('click', (event) => {
	event.preventDefault();
	if (event.target.classList.contains('clearfilter')) {
		document.querySelectorAll('input[name="filter"]').forEach(checkbox => checkbox.checked = false);
		GroupSortFilter();
		return;
	}
	const filterOptions = $('#filterOptions');
	filterOptions.classList.add('active');
	filterOptions.style.maxHeight = filterOptions.scrollHeight + 20 + 'px';
});

// from the repo, or with fromAp from another AP (the AP's own types above 0xFF)
const downloadTagtype = async (hwtype, fromAp) => {
	try {
		console.log("download tagtype " + hwtype);
		let repo = apConfig.repo || 'OpenEPaperLink/OpenEPaperLink';
		let url = fromAp ? "http://" + fromAp + "/tagtypes/" + hwtype + ".json" : "https://raw.githubusercontent.com/" + repo + "/master/resources/tagtypes/" + hwtype + ".json";
		console.log(url);

		const response = await fetch(url);
		if (!response.ok) {
			console.log("github download error " + response.status);
			return response;
		}
		const clonedResponse = response.clone();
		const fileContent = await clonedResponse.blob();

		const formData = new FormData();
		formData.append('path', "/tagtypes/" + hwtype + ".json");
		formData.append('file', fileContent, hwtype + ".json");

		const uploadResponse = await fetch('littlefs_put', {
			method: 'POST',
			body: formData
		});

		if (!uploadResponse.ok) {
			console.log("upload error " + uploadResponse.status);
		}

		return response;
	} catch (error) {
		console.log('error: ' + error);
	}
};

// tag type id as used in the file name: two hex digits, four above 0xFF
function hwTypeHex(hwtype) {
	return Number(hwtype).toString(16).toUpperCase().padStart(Number(hwtype) > 0xFF ? 4 : 2, '0');
}

// apip: the AP that has the tag, for a type of its own (above 0xFF) that this AP doesn't have
async function getTagtype(hwtype, apip) {
	if (tagTypes[hwtype] && tagTypes[hwtype].busy == false) {
		return tagTypes[hwtype];
	}

	// nice, but no possibility to invalidate this cache yet.
	/*
	const storedData = JSON.parse(localStorage.getItem("tagTypes"));
	if (storedData && storedData[hwtype]) {
		return storedData[hwtype];
	}
	*/

	if (getTagtypeBusy) {
		await new Promise(resolve => {
			const checkBusy = setInterval(() => {
				if (!getTagtypeBusy) {
					clearInterval(checkBusy);
					resolve();
				}
			}, 50);
		});
	}

	if (tagTypes[hwtype]?.busy) {
		await new Promise(resolve => {
			const checkBusy = setInterval(() => {
				if (!tagTypes[hwtype].busy) {
					clearInterval(checkBusy);
					resolve();
				}
			}, 50);
		});
	}

	if (tagTypes[hwtype]) {
		return tagTypes[hwtype];
	}

	try {
		getTagtypeBusy = true;
		tagTypes[hwtype] = { busy: true };
		let response = await fetch('tagtypes/' + hwTypeHex(hwtype) + '.json');

		// types above 0xFF are made by an AP itself, the repo doesn't have them
		if (response.status === 404 && hwtype <= 0xFF) {
			response = await downloadTagtype(hwTypeHex(hwtype));
		} else if (response.status === 404 && apip && apip != '0.0.0.0') {
			response = await downloadTagtype(hwTypeHex(hwtype), apip);
		}

		if (!response.ok) {
			let data = { name: 'unknown id ' + hwtype.toString(16).toUpperCase(), width: 0, height: 0, bpp: 0, rotatebuffer: 0, colortable: [], busy: false, usetemplate: 0 };
			tagTypes[hwtype] = data;
			getTagtypeBusy = false;
			return data;
		}
		const jsonData = await response.json();

		let data = {
			name: jsonData.name,
			width: parseInt(jsonData.width),
			height: parseInt(jsonData.height),
			bpp: parseInt(jsonData.bpp),
			rotatebuffer: jsonData.rotatebuffer,
			colortable: Object.values(jsonData.perceptual ?? jsonData.colortable),
			contentids: Object.values(jsonData.contentids ?? []),
			options: Object.values(jsonData.options ?? []),
			zlib: parseInt(jsonData.zlib_compression || "0", 16),
			g5: parseInt(jsonData.g5_compression || "0", 16),
			shortlut: parseInt(jsonData.shortlut),
			busy: false,
			usetemplate: parseInt(jsonData.usetemplate || "0", 10)
		};
		tagTypes[hwtype] = data;
		localStorage.setItem("tagTypes", JSON.stringify(tagTypes));
		getTagtypeBusy = false;

		return data;

	} catch (error) {
		console.error('Error fetching data:', error);
		getTagtypeBusy = false;
		return null;
	}
}

function dropUpload() {
	const dropZone = $('#taglist');
	let timeoutId;

	dropZone.addEventListener('dragenter', (event) => {
		const tagCard = event.target.closest('.tagcard');
		tagCard?.classList.add('drophighlight');
	});

	dropZone.addEventListener('dragover', (event) => {
		event.preventDefault();
		const tagCard = event.target.closest('.tagcard');
		tagCard?.classList.add('drophighlight');
	});

	dropZone.addEventListener('dragleave', (event) => {
		const tagCard = event.target.closest('.tagcard');
		tagCard?.classList.remove('drophighlight');
	});

	dropZone.addEventListener('drop', (event) => {
		event.preventDefault();
		const shiftKey = event.shiftKey;
		const ctrlKey = event.ctrlKey;
		const file = event.dataTransfer.files[0];
		const tagCard = event.target.closest('.tagcard');
		const mac = tagCard.dataset.mac;
		if (tagCard && file && file.type.startsWith('image/')) {
			const itemId = tagCard.id;
			const reader = new FileReader();

			reader.onload = function (e) {
				const image = new Image();
				image.src = e.target.result;

				image.onload = function () {
					const hwtype = tagCard.dataset.hwtype;
					const [width, height] = [tagTypes[hwtype].width, tagTypes[hwtype].height] || [0, 0];
					const canvas = createCanvas(width, height);
					const ctx = canvas.getContext('2d');

					scaleFactor = 0;
					if(ctrlKey) {
					// fit image
						scaleFactor = Math.min(canvas.width / image.width,
											   canvas.height / image.height);
					}
					else {
					// Default: fill screen
						scaleFactor = Math.max(canvas.width / image.width,
											   canvas.height / image.height);
					}

					const newWidth = image.width * scaleFactor;
					const newHeight = image.height * scaleFactor;

					const x = (canvas.width - newWidth) / 2;
					const y = (canvas.height - newHeight) / 2;

					if(ctrlKey) {
					// Fit option, fill background with white
						ctx.fillStyle = "white";
						ctx.fillRect(0, 0, canvas.width, canvas.height);
					}
					ctx.drawImage(image, x, y, newWidth, newHeight);

					canvas.toBlob(async (blob) => {
						const formData = new FormData();
						formData.append('mac', mac);
						if (shiftKey) formData.append('dither', '2');
						formData.append('file', blob, 'image.jpg');

						try {
							const response = await fetch('imgupload', {
								method: 'POST',
								body: formData,
							});

							if (response.ok) {
								console.log('Resized image uploaded successfully');
							} else {
								console.error('Image upload failed');
							}
						} catch (error) {
							console.error('Image upload failed', error);
						}
					}, 'image/jpeg');
				};

				image.onerror = function () {
					console.error('Failed to load image.');
				};
			};
			reader.readAsDataURL(file);

		} else if (file.type === 'application/json') {

			const reader = new FileReader();
			reader.onload = function (event) {
				const jsonContent = event.target.result;
				const formData = new FormData();
				formData.append('mac', mac);
				formData.append('json', jsonContent);
				fetch('jsonupload', {
					method: 'POST',
					body: formData,
				})
					.then(response => {
						if (response.ok) {
							console.log('JSON uploaded successfully');
						} else {
							console.error('JSON upload failed');
						}
					})
					.catch(error => {
						console.error('JSON upload failed', error);
					});
			};
			reader.readAsText(file);

		}
		tagCard.classList.remove('drophighlight');
	});

	function createCanvas(width, height) {
		const canvas = document.createElement('canvas');
		canvas.width = width;
		canvas.height = height;
		return canvas;
	}
}

const contextMenu = $('#context-menu');

$('#taglist').addEventListener('contextmenu', (e) => {
	e.preventDefault();

	const clickedGridItem = e.target.closest('.tagcard');
	if (clickedGridItem) {
		let mac = clickedGridItem.dataset.mac;
		const hwtype = clickedGridItem.dataset.hwtype;
		let contextMenuOptions = [];
		if (tagTypes[hwtype]?.width > 0) {
			contextMenuOptions.push(
				{ id: 'refresh', label: 'Force refresh' },
				{ id: 'clear', label: 'Clear pending status' }
			);
			if (clickedGridItem.dataset.isexternal == "false") {
				contextMenuOptions.push(
					{ id: 'scan', label: 'Scan channels' },
					{ id: 'reboot', label: 'Reboot tag' },
					{ id: 'deepsleep', label: 'Deep sleep tag' },
				);
			};
			if (tagTypes[hwtype]?.options?.includes("led")) {
				contextMenuOptions.push(
					{ id: 'ledflash', label: 'Flash the LED' },
					{ id: 'ledflash_long', label: 'Flash the LED (long)' },
					{ id: 'ledflash_stop', label: 'Stop flashing' }
				);
			}
		}
		contextMenuOptions.push(
			{ id: 'favorite', label: favorites.has(mac) ? 'Remove from favorites' : 'Add to favorites' },
			{ id: 'del', label: 'Delete tag from list' }
		);
		let idletime = (Date.now() / 1000) - servertimediff - clickedGridItem.dataset.lastseen;
		if ((Date.now() / 1000) - servertimediff - 600 > clickedGridItem.dataset.nextcheckin || idletime > 24 * 3600 || clickedGridItem.dataset.nextcheckin == 3216153600) {
			contextMenuOptions.push(
				{ id: 'purge', label: 'Delete all inactive tags' }
			);
		}
		contextMenu.innerHTML = '';

		const li = document.createElement('li');
		li.textContent = "Tag preview";
		li.addEventListener('click', (e) => {
			e.preventDefault();
			openPreview(mac, tagTypes[hwtype].width, tagTypes[hwtype].height);
			contextMenu.style.display = 'none';
		});
		contextMenu.appendChild(li);

		contextMenuOptions.forEach(option => {
			const li = document.createElement('li');
			li.textContent = option.label;
			li.addEventListener('click', (e) => {
				e.preventDefault();
				if (option.id == 'favorite') toggleFavorite(mac); else sendCmd(mac, option.id);
				contextMenu.style.display = 'none';
			});
			contextMenu.appendChild(li);
		});

		const contextMenuPosition = {
			left: e.clientX + window.scrollX,
			top: e.clientY + window.scrollY
		};
		contextMenu.style.left = `${contextMenuPosition.left}px`;
		contextMenu.style.top = `${contextMenuPosition.top}px`;
		contextMenu.style.display = 'block';
	}
});

document.addEventListener('click', () => {
	contextMenu.style.display = 'none';
});

function populateTimes(element) {
	for (let i = 0; i < 24; i++) {
		const option = document.createElement("option");
		option.value = i;
		option.text = i.toString().padStart(2, "0") + ":00";
		element.appendChild(option);
	}
}

function populateAPCard(msg) {
	let apip = msg.ip;
	let apid = apip.replace(/\./g, "-");
	if (!$('#ap' + apid)) {
		div = $('#apcard').cloneNode(true);
		div.setAttribute('id', 'ap' + apid);
		$('#aplist').appendChild(div);
	}
	let alias = msg.alias;
	if (!alias) alias = apip;
	$('#ap' + apid + ' .apip').innerHTML = "<a href=\"http://" + apip + "\" target=\"_new\">" + apip + "</a>";
	$('#ap' + apid + ' .apalias').innerHTML = alias;
	$('#ap' + apid + ' .aptagcount').innerHTML = msg.count;
	$('#ap' + apid + ' .apchannel').innerHTML = msg.channel;

	const elements = document.querySelectorAll('.apchannel');
	Array.from(elements).forEach(element => {
		if (element.textContent === msg.channel && element.id !== 'ap' + apid) {
			$('#ap' + apid + ' .apchannel').style.color = 'red';
			$('#ap' + apid + ' .apchannel').innerHTML += ' conflict';
		}
	});

	if (activeTab == 'aptab') {
		populateAPInfo(apip);
	}
}

function populateAPInfo(apip) {
	let apid = apip.replace(/\./g, "-");
	fetch('http://' + apip + '/sysinfo')
		.then(response => {
			if (response.status != 200) {
				$('#ap' + apid + ' .apswversion').innerHTML = "Error fetching sysinfo: " + response.status;
				return {};
			} else {
				return response.json();
			}
		})
		.then(data => {
			if (data.env) {
				let gModuleType = "";
				if (data.hasC6 == 1) {
					gModuleType = "esp32-C6";
				}
				if (data.hasH2 == 1) {
					gModuleType = "esp32-H2";
				}
				if (data.hasTslr == 1) {
					gModuleType = "TSLR";
				}
				let version = '';
				version += `env:                ${data.env}<br>`;
				version += `build date:         ${formatEpoch(data.buildtime)}<br>`;
				version += `esp32 version:      ${data.buildversion}<br>`;
				version += `psram size:         ${data.psramsize}<br>`;
				version += `flash size:         ${data.flashsize}<br>`;
				if (gModuleType) {
					version += `${gModuleType} version: 0x${parseInt(data.ap_version).toString(16).toUpperCase()}<br>`;
				}
				$('#ap' + apid + ' .apswversion').innerHTML = version;
			}
		})
		.catch(error => {
			$('#ap' + apid + ' .apswversion').innerHTML = "Error fetching sysinfo: " + error;
		});
}

function formatEpoch(epochTime) {
	const date = new Date(epochTime * 1000); // Convert seconds to milliseconds

	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-based
	const day = String(date.getDate()).padStart(2, '0');
	const hours = String(date.getHours()).padStart(2, '0');
	const minutes = String(date.getMinutes()).padStart(2, '0');

	return `${year}-${month}-${day} ${hours}:${minutes}`;
}

function setFilterAndShow(filter) {
	$('input[name="filter"][value="remote"]').checked = (filter == 'remote');
	$('input[name="filter"][value="local"]').checked = false;
	$('input[name="filter"][value="inactive"]').checked = (filter == 'inactive');
	$('input[name="filter"][value="pending"]').checked = (filter == 'pending');
	$('input[name="filter"][value="lowbatt"]').checked = (filter == 'lowbatt');
	$('input[name="filter"][value="favorites"]').checked = false;
	GroupSortFilter();
	$(`[data-target='tagtab']`).click();
}

/* dashboard (home tab) */
const apList = {};
const lastSys = {};
let sysInfo = {};
let latestRelease = null;
let dbSysinfoFetched = 0, dbLogFetched = 0, dbApsFetched = 0, dbReleaseChecked = false;

const dbEsc = text => htmlEncode(String(text ?? ''));

function dbAgo(seconds) {
	seconds = Math.max(0, seconds);
	if (seconds < 60) return Math.round(seconds) + 's ago';
	if (seconds < 3600) return Math.round(seconds / 60) + ' min ago';
	if (seconds < 48 * 3600) return Math.round(seconds / 3600) + ' h ago';
	return Math.round(seconds / 86400) + ' days ago';
}

function dbIn(seconds) {
	if (seconds < 60) return 'in ' + Math.max(0, Math.round(seconds)) + 's';
	if (seconds < 3600) return 'in ' + Math.floor(seconds / 60) + 'm ' + String(Math.round(seconds % 60)).padStart(2, '0') + 's';
	if (seconds < 48 * 3600) return 'in ' + Math.floor(seconds / 3600) + 'h ' + String(Math.floor((seconds % 3600) / 60)).padStart(2, '0') + 'm';
	return 'in ' + Math.round(seconds / 86400) + ' days';
}

// Only touch the DOM when something changed: keeps hover states and avoids flicker.
function dbSet(id, html) {
	const el = document.getElementById(id);
	if (el && el.dataset.html !== html) {
		el.innerHTML = html;
		el.dataset.html = html;
	}
}

function dbSameVersion(a, b) {
	const norm = v => String(v).replace(/(\.\d*?)0+$/, '$1').replace(/\.$/, '');
	return norm(a) == norm(b);
}

function dbDist(id, rows, color) {
	const max = Math.max(1, ...rows.map(r => r[1]));
	const html = rows.map(([label, n, c]) => `<span class="lbl" title="${dbEsc(label)}">${dbEsc(label)}</span>` +
		`<div class="track"><div class="fill" style="width:${n / max * 100}%;--c:var(${c || color})"></div></div><span class="n">${n}</span>`).join('');
	dbSet(id, html || '<span class="lbl">no data</span>');
}

function dbMeter(label, used, total, color, hint) {
	const pct = total ? Math.min(100, used / total * 100) : 0;
	return `<div class="dmeter" style="--c:var(${color})"><div class="top">${label} <span>${convertSize(total - used)} free of ${convertSize(total)}</span></div>` +
		`<div class="track"><div class="fill" style="width:${pct.toFixed(1)}%"></div></div>${hint ? `<div class="hint">${hint}</div>` : ''}</div>`;
}

// sysinfo.ethernet is only there on boards that can do Ethernet
function ethernetState(eth) {
	if (eth.active) return 'connected, in use';
	if (eth.cable) return 'cable connected, no address yet';
	if (eth.found) return 'no cable, using WiFi';
	return 'no Ethernet adapter found';
}

function dbFetchSysinfo() {
	dbSysinfoFetched = Date.now();
	fetch('sysinfo')
		.then(response => response.json())
		.then(data => {
			sysInfo = data;
			if (!dbReleaseChecked) dbCheckRelease();
		})
		.catch(() => { });
}

function dbFetchLog() {
	dbLogFetched = Date.now();
	fetch('edit?edit=log.txt', { cache: 'no-store' })
		.then(response => response.ok ? response.text() : '')
		.then(text => {
			const lines = text.split('\n').map(l => l.trim()).filter(l => l).slice(-6).reverse();
			dbSet('dbLog', lines.length ? lines.map(l => {
				const err = /crash|backtrace|error|fail|panic|watchdog|brownout/i.test(l);
				return `<div class="${err ? 'err' : ''}" title="${dbEsc(l)}">${dbEsc(l)}</div>`;
			}).join('') : '<div>log is empty</div>');
		})
		.catch(() => { });
}

// Once per page load, cached for 12 hours: the GitHub API allows 60 requests per hour.
function dbCheckRelease() {
	if (!sysInfo.buildversion) return;
	dbReleaseChecked = true;
	const repo = apConfig.repo || 'OpenEPaperLink/OpenEPaperLink';
	const key = 'latestRelease:' + repo;
	try {
		const cached = JSON.parse(localStorage.getItem(key) || 'null');
		if (cached && Date.now() - cached.checked < 12 * 3600 * 1000) {
			latestRelease = cached;
			return;
		}
	} catch (e) { }
	fetch('https://api.github.com/repos/' + repo + '/releases')
		.then(response => response.json())
		.then(releases => {
			const env = apConfig.env || sysInfo.env;
			const release = releases.find(r => r.assets.some(a => a.name === 'binaries.json') && r.assets.some(a => a.name === env + '.bin'));
			if (!release) return;
			latestRelease = { tag: release.tag_name, published: Date.parse(release.published_at) / 1000, checked: Date.now() };
			try { localStorage.setItem(key, JSON.stringify(latestRelease)); } catch (e) { }
		})
		.catch(() => { });
}

function openUpdatePage() {
	$(`[data-target='configtab']`).click();
	$('#updatebutton').click();
}

function renderDashboard() {
	if (activeTab != 'hometab') return;
	const now = Date.now() / 1000 - servertimediff;

	if (Date.now() - dbSysinfoFetched > 60000) dbFetchSysinfo();
	if (Date.now() - dbLogFetched > 60000) dbFetchLog();
	// get_ap_config makes the AP announce itself and ask the other APs; the answers arrive over the websocket
	if (socket && socket.readyState == 1 && Date.now() - dbApsFetched > 300000) {
		dbApsFetched = Date.now();
		fetch('get_ap_config').catch(() => { });
	}

	const attention = [], next = [], recent = [];
	let updated = 0, external = 0, local = 0;
	const batt = [0, 0, 0, 0], rssi = [0, 0, 0, 0], content = {}, types = {};

	$('#taglist').querySelectorAll('[data-mac]').forEach(item => {
		const mac = item.dataset.mac, tag = tagDB[mac];
		if (!tag) return;
		const name = item.querySelector('.alias')?.textContent || mac;
		if (tag.isexternal) external++; else local++;
		if (tag.updatelast > now - 3600) updated++;

		const timeout = item.classList.contains('state-timeout');
		if (timeout) {
			attention.push([0, 'signal_disconnected', '--dash-red', name, 'timeout', 'last seen ' + dbAgo(now - tag.lastseen), mac]);
		} else if (tag.nextupdate > 1672531200 && tag.nextupdate != 3216153600 && tag.nextupdate < now - 900) {
			attention.push([1, 'running_with_errors', '--dash-blue', name, 'content overdue', dbAgo(now - tag.nextupdate).replace(' ago', ' late'), mac]);
		}
		if (tag.wakeupReason == WAKEUP_REASON_FAILED_OTA_FW) attention.push([1, 'system_update', '--dash-red', name, 'firmware update rejected', '', mac]);
		if (tag.wakeupReason == WAKEUP_REASON_WDT_RESET) attention.push([2, 'restart_alt', '--dash-yellow', name, 'watchdog reset', '', mac]);

		const mv = tag.batteryMv;
		const knownBatt = mv != 0 && mv != 1337;
		if (knownBatt && mv < 2400) attention.push([2, 'battery_alert', '--dash-yellow', name, 'low battery', (mv / 1000).toFixed(2) + ' V', mac]);
		const radio = tag.RSSI && tag.RSSI != 100;
		if (radio && tag.RSSI < -85 && !timeout) attention.push([3, 'signal_cellular_1_bar', '--dash-yellow', name, 'weak signal', tag.RSSI + ' dBm', mac]);

		if (knownBatt) batt[mv > 2800 ? 0 : mv > 2600 ? 1 : mv >= 2400 ? 2 : 3]++;
		if (radio) rssi[tag.RSSI >= -65 ? 0 : tag.RSSI >= -75 ? 1 : tag.RSSI >= -85 ? 2 : 3]++;
		const contentName = getContentDefById(tag.contentMode)?.name;
		if (contentName) content[contentName] = (content[contentName] || 0) + 1;
		if (tag.RSSI) {
			const typeName = tagTypes[tag.hwType]?.name || 'type ' + hwTypeHex(tag.hwType);
			types[typeName] = (types[typeName] || 0) + 1;
		}

		if (tag.nextupdate > now && tag.nextupdate != 3216153600) next.push([tag.nextupdate, name, contentName || '', mac]);
		const canvas = item.querySelector('.tagimg');
		if (tag.updatelast > 0 && canvas && canvas.style.display == 'block' && canvas.width > 0) recent.push([tag.updatelast, name, canvas, mac]);
	});

	// status
	dbSet('dbAlias', dbEsc(apConfig.alias || 'OpenEPaperLink AP'));
	dbSet('dbServing', `&middot; ${local} tag${local == 1 ? '' : 's'}`);
	if (sysInfo.env) {
		const radioFw = sysInfo.ap_version ? ' &middot; fw ' + Number(sysInfo.ap_version).toString(16).toUpperCase().padStart(4, '0') : '';
		const channel = sysInfo.channel || apConfig.channel;
		dbSet('dbRadio', sysInfo.ap_type || sysInfo.ap_version ? `${dbEsc(sysInfo.ap_typename || 'radio')}${channel ? ' &middot; channel ' + channel : ''}${radioFw}` : 'none');
		let fw = dbEsc(sysInfo.buildversion);
		if (latestRelease && !dbSameVersion(latestRelease.tag, sysInfo.buildversion) && latestRelease.published > Number(sysInfo.buildtime) + 1800) {
			fw += `<span class="dbadge" onclick="openUpdatePage()" title="Open the update page">${dbEsc(latestRelease.tag)} available</span>`;
		}
		dbSet('dbFirmware', fw);
	}
	if (lastSys.uptime !== undefined) {
		if (lastSys.wifissid) {
			const level = lastSys.rssi >= -55 ? 4 : lastSys.rssi >= -65 ? 3 : lastSys.rssi >= -75 ? 2 : 1;
			const bars = [4, 7, 10, 14].map((h, i) => `<i class="${i < level ? 'on' : ''}" style="height:${h}px"></i>`).join('');
			dbSet('dbNetwork', `<span class="dbars">${bars}</span>${dbEsc(lastSys.wifissid)} &middot; ${lastSys.rssi} dBm`);
		} else {
			dbSet('dbNetwork', 'Ethernet');
		}
		$('#dbUptime').textContent = formatUptime(lastSys.uptime + Math.max(0, Math.round(now - lastSys.currtime)));
	}
	const timeText = new Date(now * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
	$('#dbTime').textContent = timeText + (sysInfo.env && !sysInfo.ntpsync ? ' (not synced)' : '');

	// tiles
	dbSet('dbUpdated', String(updated));
	dbSet('dbExternal', String(external));

	// needs attention
	attention.sort((a, b) => a[0] - b[0]);
	let html = attention.slice(0, 8).map(([, icon, color, name, why, value, mac]) =>
		`<li data-mac="${mac}"><span class="material-symbols-outlined dot" style="--c:var(${color})">${icon}</span>` +
		`<span class="name">${dbEsc(name)}<small>${why}</small></span><span class="val">${value}</span></li>`).join('');
	if (attention.length > 8) html += `<li onclick="setFilterAndShow('')"><span class="name"><small>and ${attention.length - 8} more</small></span></li>`;
	dbSet('dbAttention', html || '<div class="dempty"><span class="material-symbols-outlined">task_alt</span>All tags are fine</div>');

	// just updated: copies of the previews the tag cards already decoded
	$('#dbThumbCard').style.display = apConfig.preview == 0 ? 'none' : '';
	recent.sort((a, b) => b[0] - a[0]);
	const shown = recent.slice(0, 6);
	dbSet('dbThumbs', shown.length ? shown.map(([, name, , mac]) =>
		`<div class="thumb" data-mac="${mac}"><span class="frame"><canvas></canvas></span><div>${dbEsc(name)}</div><small></small></div>`).join('')
		: '<div class="dempty muted">No previews yet</div>');
	shown.forEach(([time, , source, mac]) => {
		const thumb = $(`#dbThumbs [data-mac="${mac}"]`);
		if (!thumb) return;
		const canvas = thumb.querySelector('canvas');
		if (canvas.width != source.width || canvas.height != source.height) [canvas.width, canvas.height] = [source.width, source.height];
		canvas.getContext('2d').drawImage(source, 0, 0);
		canvas.style.transform = source.style.transform;
		thumb.querySelector('small').textContent = dbAgo(now - time);
	});

	// next updates
	next.sort((a, b) => a[0] - b[0]);
	dbSet('dbNext', next.slice(0, 6).map(([time, name, contentName, mac]) =>
		`<li data-mac="${mac}"><span class="material-symbols-outlined dot" style="--c:var(--dash-teal)">schedule</span>` +
		`<span class="name">${dbEsc(name)}<small>${dbEsc(contentName)}</small></span><span class="val" data-time="${time}"></span></li>`).join('')
		|| '<div class="dempty muted">Nothing scheduled</div>');
	document.querySelectorAll('#dbNext .val').forEach(el => el.textContent = dbIn(el.dataset.time - now));

	// fleet
	dbDist('dbDistBatt', [['> 2.8 V', batt[0], '--dash-ok'], ['2.6 - 2.8 V', batt[1], '--dash-ok'], ['2.4 - 2.6 V', batt[2], '--dash-yellow'], ['< 2.4 V', batt[3], '--dash-red']]);
	dbDist('dbDistRssi', [['strong', rssi[0], '--dash-ok'], ['good', rssi[1], '--dash-ok'], ['fair', rssi[2], '--dash-yellow'], ['weak', rssi[3], '--dash-red']]);
	const top = (obj, n) => Object.entries(obj).sort((a, b) => b[1] - a[1]).slice(0, n);
	dbDist('dbDistContent', top(content, 6), '--dash-purple');
	dbDist('dbDistTypes', top(types, 6), '--dash-blue');

	// system
	if (lastSys.heap !== undefined) {
		let sys = '';
		if (sysInfo.heapsize) sys += dbMeter('Heap', sysInfo.heapsize - lastSys.heap, sysInfo.heapsize, '--dash-blue');
		if (sysInfo.psramsize && lastSys.psfree !== undefined) sys += dbMeter('PSRAM', sysInfo.psramsize - lastSys.psfree, sysInfo.psramsize, '--dash-purple');
		if (sysInfo.fssize) {
			const free = lastSys.littlefsfree;
			const color = free < 31000 ? '--dash-red' : free < 150000 ? '--dash-yellow' : '--dash-ok';
			const hint = free < 31000 ? 'File system full: content generation is paused' : free < 150000 ? 'Content generation pauses below 31 KB free' : '';
			sys += dbMeter('File system', sysInfo.fssize - free, sysInfo.fssize, color, hint);
		}
		sys += '<div class="dkv">';
		sys += `<span>Tag database</span><span>${lastSys.recordcount} records &middot; ${convertSize(lastSys.dbsize)}</span>`;
		if (sysInfo.env) {
			sys += `<span>Build</span><span>${dbEsc(sysInfo.env)} &middot; ${formatEpoch(sysInfo.buildtime)}</span>`;
			if (sysInfo.resetreason) {
				const boot = dbAgo(lastSys.uptime + Math.max(0, now - lastSys.currtime));
				sys += `<span>Last restart</span><span${sysInfo.crashed ? ' class="bad"' : ''}>${boot} &middot; ${dbEsc(sysInfo.resetreason)}${sysInfo.crashed ? ', crash details in the log' : ''}</span>`;
			}
			if (sysInfo.ntpserver !== undefined) {
				sys += sysInfo.ntpsync
					? `<span>Time sync</span><span>${dbEsc(sysInfo.ntpserver)} &middot; ${dbAgo(now - sysInfo.ntpsync)}</span>`
					: `<span>Time sync</span><span class="bad">not synced yet${sysInfo.ntpserver ? ' (' + dbEsc(sysInfo.ntpserver) + ')' : ''}</span>`;
			}
			if (sysInfo.ethernet) {
				sys += `<span>Ethernet</span><span>${ethernetState(sysInfo.ethernet)}</span>`;
			}
		}
		sys += '</div>';
		dbSet('dbSystem', sys);
	}

	// access points
	const aps = Object.values(apList).sort((a, b) => (b.ip == location.hostname) - (a.ip == location.hostname) || a.ip.localeCompare(b.ip, undefined, { numeric: true }));
	dbSet('dbAps', aps.map(ap => {
		const self = ap.ip == location.hostname;
		const conflict = ap.channel && aps.some(other => other !== ap && other.channel == ap.channel);
		return `<li data-ap="${self ? '' : dbEsc(ap.ip)}"><span class="material-symbols-outlined dot" style="--c:var(${conflict ? '--dash-red' : '--dash-ok'})">radio_button_checked</span>` +
			`<span class="name">${dbEsc(ap.alias || (self ? apConfig.alias || 'OpenEPaperLink AP' : ap.ip))}<small>${dbEsc(ap.ip)}${self ? ' &middot; this AP' : ''}</small></span>` +
			`<span class="val${conflict ? ' bad' : ''}">ch ${ap.channel}${conflict ? ' conflict' : ''} &middot; ${ap.count} tags</span></li>`;
	}).join('') || '<div class="dempty muted">Looking for access points...</div>');
}

$('#hometab').addEventListener('click', (event) => {
	const tagItem = event.target.closest('[data-mac]');
	if (tagItem) {
		loadContentCard(tagItem.dataset.mac);
		return;
	}
	const apItem = event.target.closest('[data-ap]');
	if (apItem) {
		if (apItem.dataset.ap) window.open('http://' + apItem.dataset.ap, '_blank');
		else $(`[data-target='aptab']`).click();
	}
});

// geocoding typeahead

async function searchLocations() {
	const query = $(".geoselect").value.trim();
	document.getElementById('opt#lat').value = '';
	document.getElementById('opt#lon').value = '';
	if (document.getElementById('opt#tz')) document.getElementById('opt#tz').value = '';

	if (query.length === 0) {
		$('#georesults').innerHTML = '';
		return;
	}

	try {
		const response = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${query}&count=10&language=en&format=json`);
		const data = await response.json();
		displayResults(data.results);
	} catch (error) {
		console.error('Error fetching data:', error);
	}
}

async function NoaaSearch() {
	const query = $(".noaaselect").value.trim();
	if (query.length < 2) {
		$('#georesults').innerHTML = '';
		return;
	}

	try {
		const response = await fetch(`https://api.tidesandcurrents.noaa.gov/mdapi/prod/webapi/tidepredstations.json?q=${query}`);
		const data = await response.json();
		displaygeoresults(data.stationList);
	} catch (error) {
		console.error('Error fetching data:', error);
	}
}
function displayResults(results) {
	$('#georesults').innerHTML = '';
	$('#georesults').style.top = $(".geoselect").offsetTop + $(".geoselect").offsetHeight + "px";
	$('#georesults').style.left = $(".geoselect").offsetLeft + 'px';
	// $('#georesults').style.width = $(".geoselect").offsetWidth + 'px';
	if (results) {
		results.forEach(result => {
			const option = document.createElement('div');
			option.textContent = result.name + ', ' + result.admin1 + ', ' + result.country;
			option.addEventListener('click', () => selectLocation(result));
			$('#georesults').appendChild(option);
		});
	}
}

function displaygeoresults(results) {
	$('#georesults').innerHTML = '';
	$('#georesults').style.top = $(".noaaselect").offsetTop + $(".noaaselect").offsetHeight + "px";
	$('#georesults').style.left = $(".noaaselect").offsetLeft + 'px';
	if (results) {
		results.forEach(result => {
			const option = document.createElement('div');
			option.textContent = result.etidesStnName;
			option.addEventListener('click', () => selectNoaaLocation(result));
			$('#georesults').appendChild(option);
		});
	}
}

function selectLocation(location) {
	$(".geoselect").value = location.name;
	document.getElementById('opt#lat').value = location.latitude;
	document.getElementById('opt#lon').value = location.longitude;
	if (document.getElementById('opt#tz')) document.getElementById('opt#tz').value = location.timezone;
	$('#georesults').innerHTML = '';
}

function selectNoaaLocation(location) {
	$(".noaaselect").value = location.stationId;
	$('#georesults').innerHTML = '';
}

function handleApiChange() {
  ApiOptions = document.getElementById('optforecast_type');
  selected = ApiOptions.selectedIndex;
  for (option of ApiOptions.options) {
	  let DivName = 'ApiDiv' + option.value;
	  OptionDiv = document.getElementById(DivName);
	  let DivHeight;
	  let DivDisplay;

	  if(option.value == selected) {
		  DivDisplay = 'block';
	  }
	  else {
		  DivDisplay = 'none';
		  DivHeight = '0px';
	  }
	  OptionDiv.style.display = DivDisplay;
  }
}

function debounce(func, delay) {
	let timeoutId;
	return function () {
		const context = this;
		const args = arguments;

		clearTimeout(timeoutId);
		timeoutId = setTimeout(() => {
			func.apply(context, args);
		}, delay);
	};
}

function backupTagDB() {
	localStorage.setItem("tagDB", JSON.stringify(tagDB));
}

// margin around the preview in its window, in CSS pixels
const previewMargin = 15;

function openPreview(mac, w, h) {
	const size = previewSize(w, h);
	// centre it on this window, so it lands on the same screen
	const left = Math.round(window.screenX + (window.outerWidth - size.w) / 2);
	const top = Math.round(window.screenY + (window.outerHeight - size.h) / 2);
	const previewWindow = window.open("", `PreviewWindow_${mac}`, `popup,width=${size.w},height=${size.h},left=${left},top=${top}`);

	if (previewWindow) {
		// a preview of this tag that is already open stays where the user put it
		const isNew = !previewWindow.document.getElementById('preview');
		previewWindow.mac = mac;
		previewWindows.push(previewWindow);
		const element = tagDB[mac];

		previewWindow.hash = "";
		previewWindow.pending = 0;
		previewWindow.focus();

		previewWindow.document.head.innerHTML = `<title>${tagTypes[element.hwType].name + ' ' + mac}</title>`;
		const body = previewWindow.document.body;
		body.style.cssText = `margin:0;height:100vh;overflow:hidden;background:#dddddd;display:flex;align-items:center;justify-content:center`;
		body.innerHTML = `<canvas id="preview" style="border:1px solid #888888;image-rendering:pixelated;box-sizing:content-box"></canvas>`;

		// browsers may ignore the size given to window.open (Chrome opens it as large as its own window):
		// size and centre it once it exists, then let the preview follow the window when the user resizes it
		if (isNew) setTimeout(() => {
			const outerW = size.w + previewWindow.outerWidth - previewWindow.innerWidth;
			const outerH = size.h + previewWindow.outerHeight - previewWindow.innerHeight;
			previewWindow.resizeTo(outerW, outerH);
			previewWindow.moveTo(Math.round(window.screenX + (window.outerWidth - outerW) / 2),
				Math.round(window.screenY + (window.outerHeight - outerH) / 2));
		}, 50);
		previewWindow.addEventListener('resize', () => fitPreview(previewWindow));

		showPreview(previewWindow, element);

		previewWindow.updateMessage = function (data) {
			//const messageDisplay = previewWindow.document.getElementById('messageDisplay');
			showPreview(previewWindow, data);
		};

	} else {
		console.error("Failed to open preview window.");
	}
}

function showPreview(previewWindow, element) {
	let imageSrc = "";
	const canvas = previewWindow.document.getElementById('preview');

	if (element.pending != previewWindow.pending && element.pending != 0) {
		console.log('refresh ' + element.mac);
		previewWindow.pending = element.pending;
		previewWindow.hash = "";
		let cachetag = Date.now();

		if (element.isexternal && element.contentMode == 12) {
			imageSrc = 'http://' + tagDB[element.mac].apip + '/getdata?mac=' + element.mac + '&md5=0000000000000000&c=' + cachetag;
		} else {
			imageSrc = '/getdata?mac=' + element.mac + '&md5=0000000000000000&c=' + cachetag;
		}

	} else if (element.hash != previewWindow.hash) {

		let cachetag = element.hash;
		previewWindow.hash = cachetag;
		previewWindow.pending = 0;
		if (element.isexternal && element.contentMode == 12) {
			imageSrc = 'http://' + tagDB[element.mac].apip + '/current/' + element.mac + '.raw?' + cachetag;
		} else {
			imageSrc = 'current/' + element.mac + '.raw?' + cachetag;
		}
	}

	if (imageSrc) {
		fetch(imageSrc)
			.then(response => response.arrayBuffer())
			.then(buffer => {
				// decode as on the tag cards, then turn the buffer the way the tag shows it
				const buf = document.createElement('canvas');
				drawCanvas(buffer, buf, element.hwType, element.mac);
				const turns = (tagTypes[element.hwType].rotatebuffer || 0) % 4;
				[canvas.width, canvas.height] = turns % 2 ? [buf.height, buf.width] : [buf.width, buf.height];
				const ctx = canvas.getContext('2d');
				ctx.translate(canvas.width / 2, canvas.height / 2);
				ctx.rotate(turns * Math.PI / 2);
				ctx.drawImage(buf, -buf.width / 2, -buf.height / 2);
				fitPreview(previewWindow);
			})
			.catch(error => {
				console.error('fetch preview image error:', error);
			});
	}
}

// window size (inner, CSS pixels) that shows a w x h preview at its own size
function previewSize(w, h) {
	return { w: w + 2 * previewMargin + 2, h: h + 2 * previewMargin + 2 };
}

// scale the preview to the largest size that fits the window, keeping its aspect ratio
function fitPreview(previewWindow) {
	const canvas = previewWindow.document.getElementById('preview');
	if (!canvas || !canvas.width || !canvas.height) return;
	const scale = Math.min((previewWindow.innerWidth - 2 * previewMargin - 2) / canvas.width,
		(previewWindow.innerHeight - 2 * previewMargin - 2) / canvas.height);
	canvas.style.width = Math.max(1, Math.floor(canvas.width * scale)) + 'px';
	canvas.style.height = Math.max(1, Math.floor(canvas.height * scale)) + 'px';
}
